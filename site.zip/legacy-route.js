'use strict';
const legacyPage=location.hash.slice(1);
const legacyPages=['home','characters','recruit','training','routes','bonds','calendar','plan','sources'];
location.replace('index.html#weave/'+(legacyPages.includes(legacyPage)?legacyPage:'home'));
