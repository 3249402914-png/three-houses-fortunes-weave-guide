// Reviewed 2026-10-14. Data facts and short original summaries; see research/class-source-notes.md.
(function(){'use strict';const root=window.GUIDE_REFERENCE_DATA=window.GUIDE_REFERENCE_DATA||{};root.houses=root.houses||{};root.weave=root.weave||{};root.houses.classes=[
  {
    "id": "noble",
    "name": "贵族",
    "english": "Noble",
    "category": "初始",
    "level": 0,
    "requirements": "角色初始职业",
    "seal": "不消耗准考证",
    "restriction": "按角色出身固定",
    "mastery": [
      {
        "name": "HP +5",
        "effect": "最大 HP +5",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "通过初始身份、活动或剧情取得，不能按普通考试转入。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 20
  },
  {
    "id": "commoner",
    "name": "平民",
    "english": "Commoner",
    "category": "初始",
    "level": 0,
    "requirements": "角色初始职业",
    "seal": "不消耗准考证",
    "restriction": "按角色出身固定",
    "mastery": [
      {
        "name": "HP +5",
        "effect": "最大 HP +5",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "通过初始身份、活动或剧情取得，不能按普通考试转入。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 20
  },
  {
    "id": "dancer",
    "name": "舞者",
    "english": "Dancer",
    "category": "特殊 / 专属",
    "level": 0,
    "requirements": "学院篇第 9 章白鹭杯获胜；仅一名符合参赛资格的本学级学生",
    "seal": "不消耗准考证",
    "restriction": "完成比赛后在整备的转职菜单选择；魅力 13 为比赛建议值，不是技能考试条件",
    "mastery": [
      {
        "name": "特别舞蹈",
        "effect": "舞蹈对象技巧、速度、幸运 +4，持续一回合",
        "type": "ability",
        "source": "https://www.fe3h.com/abilities/special_dance"
      }
    ],
    "summary": "通过初始身份、活动或剧情取得，不能按普通考试转入。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": null
  },
  {
    "id": "enlightened-one",
    "name": "涅槃那",
    "english": "Enlightened One",
    "category": "特殊 / 专属",
    "level": 0,
    "requirements": "第 11 章剧情解锁",
    "seal": "不消耗准考证",
    "restriction": "贝雷特 / 贝雷丝限定",
    "mastery": [
      {
        "name": "神圣之力",
        "effect": "相邻友军造成伤害 +3、受到伤害 -3",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "通过初始身份、活动或剧情取得，不能按普通考试转入。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": null
  },
  {
    "id": "armored-lord",
    "name": "重装领主",
    "english": "Armored Lord",
    "category": "特殊 / 专属",
    "level": 0,
    "requirements": "红花战争篇剧情解锁",
    "seal": "不消耗准考证",
    "restriction": "艾黛尔贾特限定",
    "mastery": [
      {
        "name": "王者之器",
        "effect": "幸运、魅力 +4",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "通过初始身份、活动或剧情取得，不能按普通考试转入。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": null
  },
  {
    "id": "high-lord",
    "name": "高阶领主",
    "english": "High Lord",
    "category": "特殊 / 专属",
    "level": 0,
    "requirements": "苍月战争篇剧情解锁",
    "seal": "不消耗准考证",
    "restriction": "帝弥托利限定",
    "mastery": [
      {
        "name": "王者之器",
        "effect": "幸运、魅力 +4",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "通过初始身份、活动或剧情取得，不能按普通考试转入。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [
      "高级领主"
    ],
    "prereq": [],
    "masteryExperience": null
  },
  {
    "id": "wyvern-master",
    "name": "飞龙领主",
    "english": "Wyvern Master",
    "category": "特殊 / 专属",
    "level": 0,
    "requirements": "翠风战争篇剧情解锁",
    "seal": "不消耗准考证",
    "restriction": "库罗德限定",
    "mastery": [
      {
        "name": "王者之器",
        "effect": "幸运、魅力 +4",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "通过初始身份、活动或剧情取得，不能按普通考试转入。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": null
  },
  {
    "id": "emperor",
    "name": "皇帝",
    "english": "Emperor",
    "category": "特殊 / 专属",
    "level": 0,
    "requirements": "红花后续剧情解锁",
    "seal": "不消耗准考证",
    "restriction": "艾黛尔贾特限定",
    "mastery": [
      {
        "name": "闪花",
        "effect": "命中后使敌人下回合不能移动；皇帝限定",
        "type": "exclusive-combat-art",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "通过初始身份、活动或剧情取得，不能按普通考试转入。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": null
  },
  {
    "id": "great-lord",
    "name": "大领主",
    "english": "Great Lord",
    "category": "特殊 / 专属",
    "level": 0,
    "requirements": "苍月后续剧情解锁",
    "seal": "不消耗准考证",
    "restriction": "帝弥托利限定",
    "mastery": [
      {
        "name": "幻月",
        "effect": "攻击后退到自身后方一格；大领主限定",
        "type": "exclusive-combat-art",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "通过初始身份、活动或剧情取得，不能按普通考试转入。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [
      "领主统帅"
    ],
    "prereq": [],
    "masteryExperience": null
  },
  {
    "id": "barbarossa",
    "name": "巴巴罗萨",
    "english": "Barbarossa",
    "category": "特殊 / 专属",
    "level": 0,
    "requirements": "翠风后续剧情解锁",
    "seal": "不消耗准考证",
    "restriction": "库罗德限定",
    "mastery": [
      {
        "name": "风神",
        "effect": "射程 2–5 的弓战技；巴巴罗萨限定",
        "type": "exclusive-combat-art",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "通过初始身份、活动或剧情取得，不能按普通考试转入。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": null
  },
  {
    "id": "myrmidon",
    "name": "剑客",
    "english": "Myrmidon",
    "category": "初级",
    "level": 5,
    "requirements": "剑术 D",
    "seal": "初级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "速度 +2",
        "effect": "速度 +2",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      },
      {
        "name": "交换位置",
        "effect": "与相邻友军交换位置",
        "type": "combat-art",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [
      "剑士"
    ],
    "prereq": [],
    "masteryExperience": 60
  },
  {
    "id": "soldier",
    "name": "士兵",
    "english": "Soldier",
    "category": "初级",
    "level": 5,
    "requirements": "枪术 D",
    "seal": "初级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "防御 +2",
        "effect": "防御 +2",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      },
      {
        "name": "替换位置",
        "effect": "将相邻友军移动到自身后方",
        "type": "combat-art",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 60
  },
  {
    "id": "fighter",
    "name": "战士",
    "english": "Fighter",
    "category": "初级",
    "level": 5,
    "requirements": "斧术 D 或弓术 D 或格斗 D（三选一）",
    "seal": "初级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "力量 +2",
        "effect": "力量 +2",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      },
      {
        "name": "推撞",
        "effect": "将相邻友军向前推动一格",
        "type": "combat-art",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 60
  },
  {
    "id": "monk",
    "name": "修道士",
    "english": "Monk",
    "category": "初级",
    "level": 5,
    "requirements": "理学 D 或信仰 D（二选一）",
    "seal": "初级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "魔力 +2",
        "effect": "魔力 +2",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      },
      {
        "name": "拉近",
        "effect": "自身后退一格，并将相邻友军拉到原位置",
        "type": "combat-art",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 60
  },
  {
    "id": "lord",
    "name": "领主",
    "english": "Lord",
    "category": "中级",
    "level": 10,
    "requirements": "剑术 D+、指挥 C",
    "seal": "中级考试准考证",
    "restriction": "三位级长限定",
    "mastery": [
      {
        "name": "魔防 +2",
        "effect": "魔防 +2",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      },
      {
        "name": "手下留情",
        "effect": "攻击不会将目标 HP 降到 1 以下",
        "type": "combat-art",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 100
  },
  {
    "id": "mercenary",
    "name": "佣兵",
    "english": "Mercenary",
    "category": "中级",
    "level": 10,
    "requirements": "剑术 C",
    "seal": "中级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "埋伏",
        "effect": "HP ≤50% 且能反击时，受攻击先出手",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 100
  },
  {
    "id": "thief",
    "name": "盗贼",
    "english": "Thief",
    "category": "中级",
    "level": 10,
    "requirements": "剑术 C",
    "seal": "中级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "偷盗",
        "effect": "速度高于敌人时可偷取非武器物品",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 100
  },
  {
    "id": "armored-knight",
    "name": "重骑士",
    "english": "Armored Knight",
    "category": "中级",
    "level": 10,
    "requirements": "斧术 C、重装 D",
    "seal": "中级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "金刚一击",
        "effect": "主动攻击时防御 +6",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [
      "重装骑士"
    ],
    "prereq": [],
    "masteryExperience": 100
  },
  {
    "id": "cavalier",
    "name": "骑士",
    "english": "Cavalier",
    "category": "中级",
    "level": 10,
    "requirements": "枪术 C、马术 D",
    "seal": "中级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "猛攻",
        "effect": "HP ≤50% 主动攻击且可追击时，追击紧接首次攻击",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 100
  },
  {
    "id": "brigand",
    "name": "土匪",
    "english": "Brigand",
    "category": "中级",
    "level": 10,
    "requirements": "斧术 C",
    "seal": "中级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "鬼神一击",
        "effect": "主动攻击时力量 +6",
        "type": "ability",
        "source": "https://www.fe3h.com/abilities/death_blow"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [
      "山贼"
    ],
    "prereq": [],
    "masteryExperience": 100
  },
  {
    "id": "archer",
    "name": "弓箭手",
    "english": "Archer",
    "category": "中级",
    "level": 10,
    "requirements": "弓术 C",
    "seal": "中级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "命中 +20",
        "effect": "命中率 +20",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 100
  },
  {
    "id": "brawler",
    "name": "拳斗士",
    "english": "Brawler",
    "category": "中级",
    "level": 10,
    "requirements": "格斗 C",
    "seal": "中级考试准考证",
    "restriction": "男性限定",
    "mastery": [
      {
        "name": "赤手空拳",
        "effect": "未装备武器也可进行格斗攻击",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 100
  },
  {
    "id": "mage",
    "name": "术师",
    "english": "Mage",
    "category": "中级",
    "level": 10,
    "requirements": "理学 C",
    "seal": "中级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "魔神一击",
        "effect": "主动攻击时魔力 +6",
        "type": "ability",
        "source": "https://www.fe3h.com/abilities/fiendish_blow"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 100
  },
  {
    "id": "dark-mage",
    "name": "暗术师",
    "english": "Dark Mage",
    "category": "中级",
    "level": 10,
    "requirements": "理学 C",
    "seal": "暗魔法考试准考证",
    "restriction": "男性限定",
    "mastery": [
      {
        "name": "蛇毒",
        "effect": "主动攻击并命中后，削减敌人最大 HP 的20%；不能致死",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 100
  },
  {
    "id": "priest",
    "name": "牧师",
    "english": "Priest",
    "category": "中级",
    "level": 10,
    "requirements": "信仰 C",
    "seal": "中级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "祈祷",
        "effect": "HP >1 时可按幸运概率以1 HP承受致死伤害",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 100
  },
  {
    "id": "pegasus-knight",
    "name": "飞马骑士",
    "english": "Pegasus Knight",
    "category": "中级",
    "level": 10,
    "requirements": "枪术 C、飞行 D",
    "seal": "中级考试准考证",
    "restriction": "女性限定",
    "mastery": [
      {
        "name": "飞燕一击",
        "effect": "主动攻击时攻速 +6",
        "type": "ability",
        "source": "https://www.fe3h.com/abilities/darting_blow"
      },
      {
        "name": "三角攻击",
        "effect": "三名友方飞行单位（含使用者）邻接同一敌人时可用；需要当前为飞行职业，不局限于飞马",
        "type": "exclusive-combat-art",
        "source": "https://www.fe3h.com/combat_arts/triangle_attack"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 100
  },
  {
    "id": "hero",
    "name": "勇者",
    "english": "Hero",
    "category": "高级",
    "level": 20,
    "requirements": "剑术 B、斧术 C",
    "seal": "高级考试准考证",
    "restriction": "男性限定",
    "mastery": [
      {
        "name": "濒死力量",
        "effect": "HP ≤25% 时力量 +8",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 150
  },
  {
    "id": "swordmaster",
    "name": "剑圣",
    "english": "Swordmaster",
    "category": "高级",
    "level": 20,
    "requirements": "剑术 A",
    "seal": "高级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "流星",
        "effect": "五次连续剑攻击，每次伤害按基础攻击的30%计算；剑圣限定",
        "type": "exclusive-combat-art",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 150
  },
  {
    "id": "assassin",
    "name": "刺客",
    "english": "Assassin",
    "category": "高级",
    "level": 20,
    "requirements": "剑术 B、弓术 C",
    "seal": "高级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "灭杀",
        "effect": "按技巧概率瞬间击杀，部分敌人免疫",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      },
      {
        "name": "暗杀",
        "effect": "可能瞬间击杀；刺客限定",
        "type": "exclusive-combat-art",
        "source": "https://www.fe3h.com/combat_arts/assassinate"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 150
  },
  {
    "id": "fortress-knight",
    "name": "要塞",
    "english": "Fortress Knight",
    "category": "高级",
    "level": 20,
    "requirements": "斧术 B、重装 B",
    "seal": "高级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "大盾",
        "effect": "按技巧概率将剑、枪、斧、格斗伤害减半",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 150
  },
  {
    "id": "paladin",
    "name": "圣骑士",
    "english": "Paladin",
    "category": "高级",
    "level": 20,
    "requirements": "枪术 B、马术 B",
    "seal": "高级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "圣盾",
        "effect": "按技巧概率将弓、魔法伤害减半",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 150
  },
  {
    "id": "wyvern-rider",
    "name": "飞龙骑士",
    "english": "Wyvern Rider",
    "category": "高级",
    "level": 20,
    "requirements": "斧术 B、飞行 C",
    "seal": "高级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "封锁防御",
        "effect": "战斗后目标防御 -6，持续一回合",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 150
  },
  {
    "id": "warrior",
    "name": "勇士",
    "english": "Warrior",
    "category": "高级",
    "level": 20,
    "requirements": "斧术 A",
    "seal": "高级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "愤怒",
        "effect": "HP ≤50% 且敌方主动攻击时必杀 +50",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 150
  },
  {
    "id": "sniper",
    "name": "狙击手",
    "english": "Sniper",
    "category": "高级",
    "level": 20,
    "requirements": "弓术 A",
    "seal": "高级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "猎箭",
        "effect": "两次连续弓攻击；狙击手限定",
        "type": "exclusive-combat-art",
        "source": "https://www.fe3h.com/combat_arts/hunters_volley"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 150
  },
  {
    "id": "grappler",
    "name": "格斗家",
    "english": "Grappler",
    "category": "高级",
    "level": 20,
    "requirements": "格斗 A",
    "seal": "高级考试准考证",
    "restriction": "男性限定",
    "mastery": [
      {
        "name": "魔法杀手",
        "effect": "装备格斗武器面对魔法时命中、回避 +20",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      },
      {
        "name": "猛铁拳",
        "effect": "三次连续格斗攻击；格斗家限定",
        "type": "exclusive-combat-art",
        "source": "https://www.fe3h.com/combat_arts/fierce_iron_fist"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 150
  },
  {
    "id": "warlock",
    "name": "术士",
    "english": "Warlock",
    "category": "高级",
    "level": 20,
    "requirements": "理学 A",
    "seal": "高级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "弓杀手",
        "effect": "装备魔法面对弓时命中、回避 +20",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 150
  },
  {
    "id": "dark-bishop",
    "name": "暗主教",
    "english": "Dark Bishop",
    "category": "高级",
    "level": 20,
    "requirements": "理学 A",
    "seal": "暗魔法考试准考证",
    "restriction": "男性限定；必须先通过暗术师认证",
    "mastery": [
      {
        "name": "生命吸收",
        "effect": "主动攻击击败敌人后，恢复自身最大 HP 的50%",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [
      "暗术师"
    ],
    "masteryExperience": 150
  },
  {
    "id": "bishop",
    "name": "主教",
    "english": "Bishop",
    "category": "高级",
    "level": 20,
    "requirements": "信仰 A",
    "seal": "高级考试准考证",
    "restriction": "无性别限制",
    "mastery": [
      {
        "name": "回复",
        "effect": "回合开始恢复最大 HP 的20%",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 150
  },
  {
    "id": "falcon-knight",
    "name": "圣飞马骑士",
    "english": "Falcon Knight",
    "category": "最上级",
    "level": 30,
    "requirements": "剑术 C、枪术 A、飞行 B+",
    "seal": "最上级考试准考证",
    "restriction": "女性限定；指导等级 C 以上",
    "mastery": [
      {
        "name": "濒死回避",
        "effect": "HP ≤25% 时回避 +30",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 200
  },
  {
    "id": "wyvern-lord",
    "name": "飞龙统帅",
    "english": "Wyvern Lord",
    "category": "最上级",
    "level": 30,
    "requirements": "枪术 C、斧术 A、飞行 A",
    "seal": "最上级考试准考证",
    "restriction": "无性别限制；指导等级 C 以上",
    "mastery": [
      {
        "name": "濒死必杀",
        "effect": "HP ≤25% 时必杀 +50",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 200
  },
  {
    "id": "mortal-savant",
    "name": "墓志铭",
    "english": "Mortal Savant",
    "category": "最上级",
    "level": 30,
    "requirements": "剑术 A、理学 B+",
    "seal": "最上级考试准考证",
    "restriction": "无性别限制；指导等级 C 以上",
    "mastery": [
      {
        "name": "明镜一击",
        "effect": "主动攻击时魔防 +6",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 200
  },
  {
    "id": "great-knight",
    "name": "重装骑士统帅",
    "english": "Great Knight",
    "category": "最上级",
    "level": 30,
    "requirements": "斧术 B+、重装 A、马术 B+",
    "seal": "最上级考试准考证",
    "restriction": "无性别限制；指导等级 C 以上",
    "mastery": [
      {
        "name": "濒死防御",
        "effect": "HP ≤25% 时防御 +8",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [
      "英勇骑士"
    ],
    "prereq": [],
    "masteryExperience": 200
  },
  {
    "id": "bow-knight",
    "name": "弓骑士",
    "english": "Bow Knight",
    "category": "最上级",
    "level": 30,
    "requirements": "枪术 C、弓术 A、马术 A",
    "seal": "最上级考试准考证",
    "restriction": "无性别限制；指导等级 C 以上",
    "mastery": [
      {
        "name": "濒死速度",
        "effect": "HP ≤25% 时速度 +8",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 200
  },
  {
    "id": "dark-knight",
    "name": "暗骑士",
    "english": "Dark Knight",
    "category": "最上级",
    "level": 30,
    "requirements": "枪术 C、理学 B+、马术 A",
    "seal": "最上级考试准考证",
    "restriction": "无性别限制；指导等级 C 以上",
    "mastery": [
      {
        "name": "封锁魔防",
        "effect": "战斗后目标魔防 -6，持续一回合",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 200
  },
  {
    "id": "holy-knight",
    "name": "神圣骑士",
    "english": "Holy Knight",
    "category": "最上级",
    "level": 30,
    "requirements": "枪术 C、信仰 B+、马术 A",
    "seal": "最上级考试准考证",
    "restriction": "无性别限制；指导等级 C 以上",
    "mastery": [
      {
        "name": "濒死魔防",
        "effect": "HP ≤25% 时魔防 +8",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 200
  },
  {
    "id": "war-master",
    "name": "战争大师",
    "english": "War Master",
    "category": "最上级",
    "level": 30,
    "requirements": "斧术 A、格斗 A",
    "seal": "最上级考试准考证",
    "restriction": "男性限定；指导等级 C 以上",
    "mastery": [
      {
        "name": "回击",
        "effect": "HP ≥50% 且敌方主动攻击时保证追击，并阻止敌方普通追击",
        "type": "ability",
        "source": "https://www.fe3h.com/abilities/quick_riposte"
      },
      {
        "name": "战鬼一击",
        "effect": "对所有敌人有特效的斧战技；战争大师限定",
        "type": "exclusive-combat-art",
        "source": "https://www.fe3h.com/combat_arts/war_masters_strike"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 200
  },
  {
    "id": "gremory",
    "name": "格莫瑞",
    "english": "Gremory",
    "category": "最上级",
    "level": 30,
    "requirements": "理学 A、信仰 A",
    "seal": "最上级考试准考证",
    "restriction": "女性限定；指导等级 C 以上",
    "mastery": [
      {
        "name": "濒死魔力",
        "effect": "HP ≤25% 时魔力 +8",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [
      "格莫瑞法师"
    ],
    "prereq": [],
    "masteryExperience": 200
  },
  {
    "id": "trickster",
    "name": "特技演员",
    "english": "Trickster",
    "category": "DLC 特殊",
    "level": 20,
    "requirements": "剑术 B、信仰 B",
    "seal": "地下考试准考证",
    "restriction": "需追加内容；必须先通过盗贼认证",
    "mastery": [
      {
        "name": "清流一击",
        "effect": "主动攻击时回避 +20",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      },
      {
        "name": "欺敌战术",
        "effect": "与五格内友军交换位置；特技演员限定",
        "type": "exclusive-combat-art",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [
      "盗贼"
    ],
    "masteryExperience": 150
  },
  {
    "id": "war-monk-cleric",
    "name": "战僧 / 战修女",
    "english": "War Monk/Cleric",
    "category": "DLC 特殊",
    "level": 20,
    "requirements": "格斗 B+、信仰 C+",
    "seal": "地下考试准考证",
    "restriction": "需追加内容",
    "mastery": [
      {
        "name": "格斗回避 +20",
        "effect": "装备格斗武器时回避 +20",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      },
      {
        "name": "远当",
        "effect": "射程 1–2、以魔力计算伤害的格斗战技；战僧 / 战修女限定",
        "type": "exclusive-combat-art",
        "source": "https://www.fe3h.com/combat_arts/pneuma_gale"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [
      "战僧",
      "战修女"
    ],
    "prereq": [],
    "masteryExperience": 150
  },
  {
    "id": "dark-flier",
    "name": "暗飞行者",
    "english": "Dark Flier",
    "category": "DLC 特殊",
    "level": 20,
    "requirements": "理学 B+、飞行 C",
    "seal": "地下考试准考证",
    "restriction": "需追加内容；女性限定",
    "mastery": [
      {
        "name": "魔力转换",
        "effect": "敌方阶段被魔法命中后，全能力 +3，持续一回合",
        "type": "ability",
        "source": "https://www.fe3h.com/abilities/transmute"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [
      "暗飞天"
    ],
    "prereq": [],
    "masteryExperience": 150
  },
  {
    "id": "valkyrie",
    "name": "瓦尔基里",
    "english": "Valkyrie",
    "category": "DLC 特殊",
    "level": 20,
    "requirements": "理学 B、马术 B",
    "seal": "地下考试准考证",
    "restriction": "需追加内容；女性限定",
    "mastery": [
      {
        "name": "慧眼一击",
        "effect": "主动攻击时命中 +30",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "技能等级是考试推荐标准；低于标准仍可能通过，以游戏显示的成功率为准。认证与精通是两个不同步骤。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": 150
  },
  {
    "id": "death-knight",
    "name": "死亡骑士",
    "english": "Death Knight",
    "category": "特殊 / 专属",
    "level": 0,
    "requirements": "红花第 13 章随伊艾里扎加入",
    "seal": "不消耗准考证",
    "restriction": "伊艾里扎限定；免费更新追加",
    "mastery": [
      {
        "name": "反击",
        "effect": "忽略普通距离限制反击；不能覆盖禁止反击效果",
        "type": "ability",
        "source": "https://serenesforest.net/three-houses/classes/class-abilities-arts/"
      }
    ],
    "summary": "通过初始身份、活动或剧情取得，不能按普通考试转入。",
    "source": "https://serenesforest.net/three-houses/classes/detailed-view/",
    "aliases": [],
    "prereq": [],
    "masteryExperience": null
  }
];
root.weave.classes=[
  {
    "id": "noble",
    "name": "贵族",
    "english": "Noble",
    "category": "初始",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Noble"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ]
  },
  {
    "id": "commoner",
    "name": "平民",
    "english": "Commoner",
    "category": "初始",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Commoner"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ]
  },
  {
    "id": "gladiator",
    "name": "角斗士",
    "english": "Gladiator",
    "category": "初级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Gladiator"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      10,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ]
  },
  {
    "id": "hunter",
    "name": "猎人",
    "english": "Hunter",
    "category": "初级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Hunter"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      0,
      0,
      10,
      10,
      0,
      0,
      0,
      0
    ]
  },
  {
    "id": "soldier",
    "name": "士兵",
    "english": "Soldier",
    "category": "初级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Soldier"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      5,
      0,
      -5,
      5,
      10,
      0,
      0,
      0
    ]
  },
  {
    "id": "ornius-rider",
    "name": "奥尔尼乌斯骑手",
    "english": "Ornius Rider",
    "category": "初级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Ornius Rider"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      0,
      0,
      10,
      0,
      0,
      5,
      5,
      0
    ]
  },
  {
    "id": "diviner",
    "name": "占卜师",
    "english": "Diviner",
    "category": "初级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Diviner"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      5,
      -5,
      15,
      0,
      5,
      -5,
      10,
      0,
      0
    ]
  },
  {
    "id": "myrmidon",
    "name": "剑士",
    "english": "Myrmidon",
    "category": "中级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Myrmidon"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      0,
      0,
      15,
      10,
      0,
      0,
      5,
      5
    ]
  },
  {
    "id": "brigand",
    "name": "山贼",
    "english": "Brigand",
    "category": "中级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Brigand"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      15,
      -5,
      5,
      0,
      5,
      0,
      0,
      5
    ]
  },
  {
    "id": "pugilist",
    "name": "拳斗士",
    "english": "Pugilist",
    "category": "中级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Pugilist"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      10,
      -5,
      10,
      5,
      10,
      0,
      0,
      5
    ]
  },
  {
    "id": "archer",
    "name": "弓箭手",
    "english": "Archer",
    "category": "中级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Archer"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      0,
      0,
      10,
      15,
      5,
      0,
      5,
      5
    ]
  },
  {
    "id": "rogue",
    "name": "盗贼",
    "english": "Rogue",
    "category": "中级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Rogue"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      0,
      0,
      15,
      10,
      0,
      5,
      5,
      0
    ]
  },
  {
    "id": "armored-knight",
    "name": "重装骑士",
    "english": "Armored Knight",
    "category": "中级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Armored Knight"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      10,
      -5,
      -5,
      5,
      25,
      -5,
      0,
      5
    ]
  },
  {
    "id": "light-cavalry",
    "name": "轻骑兵",
    "english": "Light Cavalry",
    "category": "中级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Light Cavalry"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      5,
      -5,
      5,
      0,
      5,
      0,
      5,
      10
    ]
  },
  {
    "id": "charioteer",
    "name": "战车兵",
    "english": "Charioteer",
    "category": "中级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Charioteer"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      5,
      -5,
      -5,
      15,
      10,
      0,
      5,
      10
    ]
  },
  {
    "id": "armored-ornius-rider",
    "name": "重装奥尔尼乌斯骑手",
    "english": "Armored Ornius Rider",
    "category": "中级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Armored Ornius Rider"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      0,
      -5,
      10,
      5,
      10,
      0,
      5,
      5
    ]
  },
  {
    "id": "wing-soldier",
    "name": "翼兵",
    "english": "Wing Soldier",
    "category": "中级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Wing Soldier"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      0,
      5,
      0,
      5,
      5,
      5,
      5,
      10
    ]
  },
  {
    "id": "shaman",
    "name": "萨满",
    "english": "Shaman",
    "category": "中级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Shaman"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      5,
      -5,
      15,
      10,
      10,
      -10,
      10,
      10,
      0
    ]
  },
  {
    "id": "priest",
    "name": "祭司",
    "english": "Priest",
    "category": "中级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Priest"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      5,
      -5,
      10,
      5,
      5,
      -10,
      15,
      15,
      10
    ]
  },
  {
    "id": "shido",
    "name": "剑道士",
    "english": "Shido",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Shido"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      5,
      0,
      15,
      10,
      0,
      -5,
      5,
      5
    ]
  },
  {
    "id": "warrior",
    "name": "勇士",
    "english": "Warrior",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Warrior"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      20,
      20,
      -5,
      0,
      0,
      5,
      -5,
      0,
      5
    ]
  },
  {
    "id": "blacksmith",
    "name": "铁匠",
    "english": "Blacksmith",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Blacksmith"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      10,
      10,
      0,
      5,
      10,
      10,
      0,
      5
    ]
  },
  {
    "id": "sniper",
    "name": "狙击手",
    "english": "Sniper",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Sniper"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      5,
      0,
      10,
      20,
      5,
      5,
      5,
      5
    ]
  },
  {
    "id": "forest-knight",
    "name": "森林骑士",
    "english": "Forest Knight",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Forest Knight"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      5,
      0,
      10,
      10,
      5,
      5,
      5,
      5
    ]
  },
  {
    "id": "ranger",
    "name": "游侠",
    "english": "Ranger",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Ranger"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      5,
      0,
      15,
      15,
      0,
      10,
      15,
      0
    ]
  },
  {
    "id": "guardian",
    "name": "守护者",
    "english": "Guardian",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Guardian"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      10,
      0,
      0,
      5,
      10,
      15,
      5,
      5
    ]
  },
  {
    "id": "dreadnought",
    "name": "重装统领",
    "english": "Dreadnought",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Dreadnought"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      15,
      -5,
      -10,
      5,
      30,
      -10,
      0,
      5
    ]
  },
  {
    "id": "bardinger",
    "name": "重骑兵",
    "english": "Bardinger",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Bardinger"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      10,
      -5,
      0,
      0,
      5,
      10,
      5,
      10
    ]
  },
  {
    "id": "elephant-rider",
    "name": "象骑兵",
    "english": "Elephant Rider",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Elephant Rider"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      20,
      10,
      -5,
      -10,
      20,
      15,
      -5,
      5,
      10
    ]
  },
  {
    "id": "caladrius",
    "name": "卡拉德里乌斯",
    "english": "Caladrius",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Caladrius"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      0,
      10,
      10,
      5,
      10,
      10,
      5,
      5
    ]
  },
  {
    "id": "dragoon",
    "name": "龙骑兵",
    "english": "Dragoon",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Dragoon"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      5,
      0,
      5,
      0,
      10,
      10,
      10,
      5
    ]
  },
  {
    "id": "ovate",
    "name": "高阶占卜师",
    "english": "Ovate",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Ovate"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      -5,
      20,
      5,
      15,
      -10,
      15,
      10,
      0
    ]
  },
  {
    "id": "bishop",
    "name": "主教",
    "english": "Bishop",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Bishop"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      -5,
      15,
      0,
      5,
      -10,
      20,
      20,
      10
    ]
  },
  {
    "id": "troubadour",
    "name": "神官骑士",
    "english": "Troubadour",
    "category": "高级",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Troubadour"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      0,
      15,
      0,
      5,
      5,
      15,
      15,
      10
    ]
  },
  {
    "id": "swordmaster",
    "name": "剑圣",
    "english": "Swordmaster",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Swordmaster"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      10,
      0,
      20,
      15,
      0,
      0,
      5,
      5
    ]
  },
  {
    "id": "high-savant",
    "name": "贤者剑士",
    "english": "High Savant",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "High Savant"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      15,
      15,
      10,
      5,
      5,
      5,
      5,
      5
    ]
  },
  {
    "id": "battlemaster",
    "name": "战斗大师",
    "english": "Battlemaster",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Battlemaster"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      25,
      25,
      -5,
      5,
      -5,
      10,
      -5,
      -5,
      5
    ]
  },
  {
    "id": "war-monk",
    "name": "战僧",
    "english": "War Monk",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "War Monk"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      10,
      0,
      15,
      0,
      5,
      15,
      5,
      5
    ]
  },
  {
    "id": "bow-adept",
    "name": "弓术达人",
    "english": "Bow Adept",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Bow Adept"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      5,
      0,
      15,
      20,
      5,
      5,
      5,
      5
    ]
  },
  {
    "id": "bow-knight",
    "name": "弓骑士",
    "english": "Bow Knight",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Bow Knight"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      10,
      0,
      15,
      10,
      5,
      0,
      5,
      5
    ]
  },
  {
    "id": "shadow-seeker",
    "name": "追影者",
    "english": "Shadow Seeker",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Shadow Seeker"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      5,
      0,
      25,
      15,
      0,
      10,
      15,
      0
    ]
  },
  {
    "id": "sentinel",
    "name": "哨卫",
    "english": "Sentinel",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Sentinel"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      15,
      0,
      5,
      5,
      10,
      15,
      5,
      5
    ]
  },
  {
    "id": "castle-knight",
    "name": "城堡骑士",
    "english": "Castle Knight",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Castle Knight"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      25,
      20,
      -5,
      -15,
      5,
      30,
      -10,
      0,
      5
    ]
  },
  {
    "id": "orichaldia",
    "name": "奥里哈尔迪亚",
    "english": "Orichaldia",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Orichaldia"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      15,
      -5,
      5,
      0,
      5,
      5,
      5,
      10
    ]
  },
  {
    "id": "great-knight",
    "name": "英勇骑士",
    "english": "Great Knight",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Great Knight"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      20,
      20,
      -5,
      -10,
      0,
      15,
      -10,
      0,
      5
    ]
  },
  {
    "id": "celestial-trooper",
    "name": "天骑兵",
    "english": "Celestial Trooper",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Celestial Trooper"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      5,
      -5,
      10,
      5,
      5,
      15,
      15,
      10
    ]
  },
  {
    "id": "bau-lord",
    "name": "鲍领主",
    "english": "Bau Lord",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Bau Lord"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      5,
      0,
      5,
      0,
      10,
      10,
      10,
      5
    ]
  },
  {
    "id": "druid",
    "name": "德鲁伊",
    "english": "Druid",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Druid"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      -5,
      30,
      10,
      15,
      -10,
      20,
      10,
      0
    ]
  },
  {
    "id": "wiseman",
    "name": "贤者",
    "english": "Wiseman",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Wiseman"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      -5,
      20,
      5,
      0,
      -10,
      25,
      20,
      10
    ]
  },
  {
    "id": "valkyrium",
    "name": "瓦尔基里姆",
    "english": "Valkyrium",
    "category": "后期职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "Valkyrium"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      0,
      15,
      5,
      5,
      5,
      10,
      15,
      10
    ]
  },
  {
    "id": "the-blade",
    "name": "神刃",
    "english": "The Blade",
    "category": "神阶职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "The Blade"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      10,
      10,
      20,
      20,
      5,
      5,
      5,
      10
    ]
  },
  {
    "id": "the-apsara",
    "name": "天女",
    "english": "The Apsara",
    "category": "神阶职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "The Apsara"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      5,
      10,
      25,
      15,
      5,
      5,
      10,
      30
    ]
  },
  {
    "id": "the-eternal",
    "name": "永恒者",
    "english": "The Eternal",
    "category": "神阶职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "The Eternal"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      30,
      30,
      0,
      10,
      0,
      15,
      0,
      0,
      10
    ]
  },
  {
    "id": "the-godhand",
    "name": "神之手",
    "english": "The Godhand",
    "category": "神阶职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "The Godhand"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      10,
      10,
      15,
      5,
      10,
      15,
      5,
      10
    ]
  },
  {
    "id": "the-calamity",
    "name": "灾厄",
    "english": "The Calamity",
    "category": "神阶职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "The Calamity"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      5,
      15,
      25,
      20,
      5,
      15,
      15,
      5
    ]
  },
  {
    "id": "the-trident",
    "name": "三叉戟",
    "english": "The Trident",
    "category": "神阶职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "The Trident"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      15,
      15,
      5,
      10,
      10,
      15,
      15,
      5,
      10
    ]
  },
  {
    "id": "the-cavalier",
    "name": "神骑士",
    "english": "The Cavalier",
    "category": "神阶职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "The Cavalier"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      20,
      15,
      5,
      10,
      10,
      15,
      10,
      5,
      15
    ]
  },
  {
    "id": "the-avatar",
    "name": "神之化身",
    "english": "The Avatar",
    "category": "神阶职业",
    "level": null,
    "requirements": "认证技能等级尚未核实；请以本作游戏内职业考试详情为准",
    "seal": "准考证种类尚未核实",
    "restriction": "加入条件与角色限制尚未核实",
    "mastery": [],
    "summary": "已有职业名称与成长表；认证要求和精通效果仍需逐项确认，不能沿用风花雪月的同名职业条件。中文名供查询，保留英文便于对照。",
    "source": "https://serenesforest.net/fortunes-weave/classes/growth-rates/",
    "aliases": [
      "The Avatar"
    ],
    "verified": false,
    "verificationNote": "来源仅支持职业名称与成长数值，不支持本条的认证条件。",
    "growth": [
      10,
      -5,
      30,
      10,
      5,
      -5,
      30,
      20,
      10
    ]
  }
];
})();
