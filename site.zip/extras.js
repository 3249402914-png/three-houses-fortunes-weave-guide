'use strict';
const EXTRA={
  "alois": {
    "growthRates": {
      "hp": 45,
      "str": 45,
      "mag": 20,
      "dex": 35,
      "spd": 40,
      "lck": 30,
      "def": 40,
      "res": 20,
      "cha": 40
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "A",
        "growth": 1
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "B",
        "growth": 1
      },
      "reason": {
        "level": "E",
        "growth": -1
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "C",
        "growth": 0
      },
      "heavyArmor": {
        "level": "C",
        "growth": 1
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": -1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Fire",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Bolganone",
        "faith": "Recover"
      }
    },
    "gifts": [
      "Ancient Coin",
      "Floral Adornment",
      "Fishing Float",
      "Sunflower"
    ],
    "dislikedGifts": [
      "Exotic Spices",
      "Monarch Studies Book"
    ],
    "lostItems": [
      "Introduction to Magic",
      "Foreign Gold Coin",
      "Mysterious Notebook"
    ],
    "birthday": {
      "month": "Ethereal",
      "day": 1,
      "year": 1135
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Crescent-Moon Tea",
        "Honeyed-Fruit Blend"
      ],
      "topics": [
        "A dinner invitation",
        "Gardening mishaps",
        "Someone you look up to",
        "A new gambit",
        "Gifts you'd like to receive",
        "Strange fish in the pond",
        "A place you'd like to visit",
        "Good jokes",
        "Tell me about yourself",
        "A strong battalion",
        "I heard some gossip",
        "Thanks for everything",
        "A word of advice",
        "I'm counting on you",
        "The ideal professor",
        "Cats",
        "Mighty weapons",
        "The last battle",
        "Children at the market",
        "Monastery rules",
        "The opera",
        "Close calls",
        "Monastery security",
        "The view from the bridge",
        "Cooking mishaps",
        "Our first meeting",
        "Things that bother you",
        "Equipment upkeep",
        "Overcoming weaknesses",
        "Working hours for guards",
        "Exploring the monastery",
        "Past laughs",
        "Working together",
        "Favorite sweets",
        "Perfect recipes",
        "You seem well",
        "First crushes",
        "Plans for the future",
        "You're doing great work",
        "Fodlan's future",
        "School days",
        "Your ambitions",
        "Food in the dining hall",
        "Shareable snacks"
      ]
    }
  },
  "anna": {
    "growthRates": {
      "hp": 35,
      "str": 35,
      "mag": 35,
      "dex": 45,
      "spd": 55,
      "lck": 45,
      "def": 30,
      "res": 40,
      "cha": 50
    },
    "skills": {
      "sword": {
        "level": "D",
        "growth": 1
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "E+",
        "growth": 1
      },
      "bow": {
        "level": "E+",
        "growth": 1
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": -1
      },
      "faith": {
        "level": "E+",
        "growth": 1
      },
      "authority": {
        "level": "E",
        "growth": -1
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Fire",
        "faith": "Heal"
      },
      "D+": {
        "reason": "Thunder",
        "faith": "Nosferatu"
      },
      "C": {
        "faith": "Ward"
      },
      "B": {
        "faith": "Rescue"
      },
      "A": {
        "reason": "Meteor"
      }
    },
    "gifts": [
      "Blue Cheese",
      "Coffee Beans",
      "Exotic Spices",
      "Goddess Statuette",
      "Landscape Painting",
      "Forget-me-nots"
    ],
    "dislikedGifts": [
      "Fishing Float",
      "Smoked Meat"
    ],
    "lostItems": [
      "Secret Ledger",
      "Balance Scale",
      "Rare Item Index"
    ],
    "birthday": {
      "month": "Garland Moon",
      "day": 9,
      "year": 1155
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Seiros Tea",
        "Dagda Fruit Blend",
        "Bergamot"
      ],
      "topics": [
        "A dinner invitation",
        "Food in the dining hall",
        "Relaxing at the sauna",
        "A place you'd like to visit",
        "Gardening mishaps",
        "Reliable allies",
        "A strong battalion",
        "Gifts you'd like to receive",
        "Shareable snacks",
        "A word of advice",
        "Guessing someone's age",
        "Strange fish in the pond",
        "Books you've read recently",
        "Heart-racing memories",
        "Tell me about yourself",
        "Cats",
        "I heard some gossip",
        "Thanks for everything",
        "Children at the market",
        "I'm counting on you",
        "The ideal professor",
        "Classes you might enjoy",
        "Likeable allies",
        "The ideal relationship",
        "Close calls",
        "Mighty weapons",
        "The library's collection",
        "Cooking mishaps",
        "Monastery mysteries",
        "The opera",
        "Dreamy knights",
        "Monastery rules",
        "The view from the bridge",
        "Equipment upkeep",
        "Money-making secrets",
        "Working hours for guards",
        "Exploring the monastery",
        "Our first meeting",
        "Working together",
        "Fashion",
        "Overcoming weaknesses",
        "You seem different",
        "Favorite sweets",
        "Past laughs",
        "You seem well",
        "First crushes",
        "Perfect recipes",
        "You're doing great work",
        "Fodlan's future",
        "Plans for the future"
      ]
    }
  },
  "annette": {
    "growthRates": {
      "hp": 25,
      "str": 30,
      "mag": 50,
      "dex": 50,
      "spd": 35,
      "lck": 35,
      "def": 20,
      "res": 30,
      "cha": 35
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "E+",
        "growth": 1
      },
      "bow": {
        "level": "E",
        "growth": -1
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "D+",
        "growth": 1
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "E+",
        "growth": 1
      },
      "heavyArmor": {
        "level": "E",
        "growth": -1
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Wind",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Cutting Gale",
        "faith": "Recover"
      },
      "B": {
        "reason": "Sagittae"
      },
      "A": {
        "reason": "Excalibur",
        "faith": "Abraxas"
      }
    },
    "gifts": [
      "Arithmetic Textbook",
      "Book of Sheet Music",
      "Stylish Hair Clip"
    ],
    "dislikedGifts": [
      "Ceremonial Sword",
      "Hunting Dagger",
      "Coffee Beans"
    ],
    "lostItems": [
      "Unfinished Score",
      "School of Sorcery Book",
      "Wax Diptych"
    ],
    "birthday": {
      "month": "Harpstring Moon",
      "day": 9,
      "year": 1163
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Sweet-Apple Blend",
        "Rose Petal Blend",
        "Almond Blend"
      ],
      "topics": [
        "A dinner invitation",
        "Gardening mishaps",
        "Tell me about yourself",
        "A new gambit",
        "Gifts you'd like to receive",
        "Thanks for everything",
        "A place you'd like to visit",
        "Guessing someone's age",
        "The courtyard couple",
        "A word of advice",
        "Hopes for your future",
        "The ideal professor",
        "Books you've read recently",
        "I'm counting on you",
        "The ideal relationship",
        "Children at the market",
        "Kitchen catastrophes",
        "The last battle",
        "Close calls",
        "Likable allies",
        "The library's collection",
        "Cooking mishaps",
        "Our first meeting",
        "The opera",
        "Cute monks",
        "Overcoming weaknesses",
        "Things that bother you",
        "Dining partners",
        "Past laughs",
        "Things you find romantic",
        "Dreamy knights",
        "Perfect recipes",
        "Working together",
        "Equipment upkeep",
        "Plans for the future",
        "You seem different",
        "Evaluating allies",
        "Relaxing at the sauna",
        "You seem well",
        "Exploring the monastery",
        "School days",
        "You're doing great work",
        "Fashion",
        "School uniforms",
        "Your ambitions",
        "Favorite sweets",
        "Shareable snacks",
        "Food in the dining hall",
        "Someone you look up to"
      ]
    }
  },
  "ashe": {
    "growthRates": {
      "hp": 35,
      "str": 35,
      "mag": 25,
      "dex": 55,
      "spd": 50,
      "lck": 40,
      "def": 20,
      "res": 35,
      "cha": 25
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "axe": {
        "level": "E+",
        "growth": 1
      },
      "bow": {
        "level": "D",
        "growth": 1
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": -1
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Wind",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Cutting Gale",
        "faith": "Physic"
      }
    },
    "gifts": [
      "Ancient Coin",
      "Exotic Spices",
      "Legend of Chivalry",
      "Tasty Baked Treat",
      "Violet"
    ],
    "dislikedGifts": [
      "Arithmetic Textbook",
      "Monarch Studies Book",
      "Board Game"
    ],
    "lostItems": [
      "Moon Knight's Tale",
      "Evil-Repelling Amulet",
      "Bundle of Herbs"
    ],
    "birthday": {
      "month": "Wyvern Moon",
      "day": 17,
      "year": 1163
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Mint Leaves",
        "Angelica Tea"
      ],
      "topics": [
        "A dinner invitation",
        "Gardening mishaps",
        "Thanks for everything",
        "A place you'd like to visit",
        "Gifts you'd like to receive",
        "The existence of Crests",
        "A strong battalion",
        "I'm counting on you",
        "The ideal professor",
        "A word of advice",
        "Monastery security",
        "The last battle",
        "Being the perfect knight",
        "Past laughs",
        "The library's collection",
        "Books you've read recently",
        "Perfect recipes",
        "Things that bother you",
        "Cats",
        "Plans for the future",
        "Working hours for guards",
        "Children at the market",
        "School days",
        "Working together",
        "Close calls",
        "Shareable snacks",
        "You seem well",
        "Dreamy knights",
        "Someone you look up to",
        "Your ambitions",
        "Equipment upkeep",
        "Strange fish in the pond",
        "Favorite sweets",
        "Tell me about yourself"
      ]
    }
  },
  "balthus": {
    "growthRates": {
      "hp": 50,
      "str": 50,
      "mag": 30,
      "dex": 25,
      "spd": 30,
      "lck": 20,
      "def": 45,
      "res": 30,
      "cha": 30
    },
    "skills": {
      "sword": {
        "level": "E+",
        "growth": 1
      },
      "lance": {
        "level": "E",
        "growth": -1
      },
      "axe": {
        "level": "D+",
        "growth": 1
      },
      "bow": {
        "level": "E",
        "growth": -1
      },
      "brawl": {
        "level": "D+",
        "growth": 1
      },
      "reason": {
        "level": "E",
        "buddingTalent": true
      },
      "faith": {
        "level": "E",
        "growth": 1
      },
      "authority": {
        "level": "E+",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": 1
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": -1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Fire",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Bolganone"
      },
      "C+": {
        "faith": "Seraphim"
      },
      "B": {
        "faith": "Restore"
      },
      "A": {
        "reason": "Ragnarok"
      }
    },
    "gifts": [
      "Ancient Coin",
      "Blue Cheese",
      "Ceremonial Sword",
      "Whetstone"
    ],
    "dislikedGifts": [
      "Fishing Float",
      "Watering Can",
      "Armored Bear Stuffy"
    ],
    "lostItems": [
      "Well-Worn Hammock",
      "Stiff Hand Wrap"
    ],
    "birthday": {
      "month": "Blue Sea Moon",
      "day": 9,
      "year": 1153
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Almyran Pine Needles",
        "Ginger Tea"
      ],
      "topics": [
        "A dinner invitation",
        "First crushes",
        "School days",
        "A new gambit",
        "Food in the dining hall",
        "Shareable snacks",
        "A place you'd like to visit",
        "Gardening mishaps",
        "Strange fish in the pond",
        "A strong battalion",
        "Hopes for your future",
        "Tell me about yourself",
        "A word of advice",
        "I heard some gossip",
        "Thanks for everything",
        "Capable comrades",
        "I'm counting on you",
        "The last battle",
        "Classes you might enjoy",
        "Likable allies",
        "The view from the bridge",
        "Close calls",
        "Mighty weapons",
        "Things that bother you",
        "Cooking mishaps",
        "Mountain folk traditions",
        "Things you find romantic",
        "Cute monks",
        "Our first meeting",
        "Working together",
        "Dining partners",
        "Overcoming weaknesses",
        "You seem well",
        "Equipment upkeep",
        "Past laughs",
        "You're doing great work",
        "Evaluating allies",
        "Potential training partners",
        "Your ambitions",
        "Exploring the monastery",
        "Relaxing at the sauna"
      ]
    }
  },
  "bernadetta": {
    "growthRates": {
      "hp": 35,
      "str": 35,
      "mag": 20,
      "dex": 55,
      "spd": 50,
      "lck": 25,
      "def": 20,
      "res": 30,
      "cha": 35
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": -1
      },
      "lance": {
        "level": "E+",
        "growth": 1
      },
      "axe": {
        "level": "E",
        "growth": -1
      },
      "bow": {
        "level": "D",
        "growth": 1
      },
      "brawl": {
        "level": "E",
        "growth": -1
      },
      "reason": {
        "level": "E",
        "growth": 0
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": -1
      },
      "riding": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Blizzard",
        "faith": "Heal"
      },
      "D+": {
        "reason": "Thunder",
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Thoron",
        "faith": "Physic"
      },
      "A": {
        "reason": "Fimbulvetr",
        "faith": "Rescue"
      }
    },
    "gifts": [
      "Armored Bear Stuffy",
      "Book of Sheet Music",
      "Dapper Handkerchief",
      "Landscape Painting",
      "Watering Can",
      "Pitcher Plant"
    ],
    "dislikedGifts": [
      "Training Weight",
      "Hunting Dagger",
      "Ceremonial Sword"
    ],
    "lostItems": [
      "Needle and Thread",
      "Still-Life Picture",
      "Hedgehog Case"
    ],
    "birthday": {
      "month": "Ethereal Moon",
      "day": 12,
      "year": 1162
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Albinean Berry Blend",
        "Honeyed-Fruit Blend"
      ],
      "topics": [
        "A place you'd like to visit",
        "I heard some gossip",
        "Thanks for everything",
        "A word of advice",
        "I'm counting on you",
        "The courtyard couple",
        "Books you've read recently",
        "Insectivorous plants",
        "The ideal relationship",
        "Cats",
        "Likable allies",
        "The last battle",
        "Children at the market",
        "Our first meeting",
        "The library's collection",
        "Close calls",
        "Overcoming weaknesses",
        "The view from the bridge",
        "Cooking mishaps",
        "Past laughs",
        "Things that bother you",
        "Cute monks",
        "Perfect recipes",
        "Things you find romantic",
        "Exploring the monastery",
        "Plans for the future",
        "You seem different",
        "Fashion",
        "School days",
        "You seem well",
        "Favorite sweets",
        "School uniforms",
        "You're doing great work",
        "Food in the dining hall",
        "Shareable snacks",
        "Gifts you'd like to receive",
        "Tell me about yourself"
      ]
    }
  },
  "byleth": {
    "growthRates": {
      "hp": 45,
      "str": 45,
      "mag": 35,
      "dex": 45,
      "spd": 45,
      "lck": 45,
      "def": 35,
      "res": 30,
      "cha": 45
    },
    "skills": {
      "sword": {
        "level": "D+",
        "growth": 1
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "E",
        "growth": 0
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E+",
        "growth": 1
      },
      "reason": {
        "level": "E",
        "growth": 0
      },
      "faith": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "authority": {
        "level": "D",
        "growth": 1
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Fire",
        "faith": "Heal"
      },
      "D+": {
        "reason": "Thunder",
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Bolganone",
        "faith": "Recover"
      },
      "A": {
        "reason": "Ragnarok",
        "faith": "Aura"
      }
    },
    "gifts": [],
    "lostItems": [],
    "birthday": {
      "month": null,
      "day": null,
      "year": 1159
    },
    "gender": "M/F"
  },
  "caspar": {
    "growthRates": {
      "hp": 55,
      "str": 45,
      "mag": 25,
      "dex": 45,
      "spd": 45,
      "lck": 40,
      "def": 30,
      "res": 20,
      "cha": 25
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "D",
        "growth": 1
      },
      "bow": {
        "level": "E",
        "growth": -1
      },
      "brawl": {
        "level": "E+",
        "growth": 1
      },
      "reason": {
        "level": "E",
        "growth": -1
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "E",
        "growth": -1
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Fire",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Bolganone",
        "faith": "Recover"
      }
    },
    "gifts": [
      "Smoked Meat",
      "Training Weight",
      "Whetstone",
      "Hunting Dagger"
    ],
    "dislikedGifts": [
      "Fishing Float",
      "Floral Adornment",
      "Stylish Hair Clip"
    ],
    "lostItems": [
      "Thunderbrand Replica",
      "Tattered Overcoat",
      "Grounding Charm"
    ],
    "birthday": {
      "month": "Blue Sea Moon",
      "day": 1,
      "year": 1163
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Ginger Tea"
      ],
      "topics": [
        "A dinner invitation",
        "Gardening mishaps",
        "Someone you look up to",
        "A new gambit",
        "Hopes for your future",
        "Strange fish in the pond",
        "A place you'd like to visit",
        "I'm counting on you",
        "Tell me about yourself",
        "A strong battalion",
        "Methods for growing taller",
        "Thanks for everything",
        "A word of advice",
        "Mighty weapons",
        "The last battle",
        "Cats",
        "Our first meeting",
        "The view from the bridge",
        "Children at the market",
        "Overcoming weaknesses",
        "Things that bother you",
        "Classes you might enjoy",
        "Past laughs",
        "Working hours for guards",
        "Close calls",
        "Perfect recipes",
        "Working together",
        "Cooking mishaps",
        "Plans for the future",
        "You seem well",
        "Dreamy knights",
        "Potential training partners",
        "You're doing great work",
        "Equipment upkeep",
        "Relaxing at the sauna",
        "Your ambitions",
        "Exploring the monastery",
        "School days",
        "Food in the dining hall",
        "Shareable snacks"
      ]
    }
  },
  "catherine": {
    "growthRates": {
      "hp": 50,
      "str": 50,
      "mag": 25,
      "dex": 40,
      "spd": 55,
      "lck": 30,
      "def": 30,
      "res": 20,
      "cha": 25
    },
    "skills": {
      "sword": {
        "level": "A",
        "growth": 1
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "E",
        "growth": 0
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "C+",
        "growth": 1
      },
      "reason": {
        "level": "E",
        "growth": -1
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Fire",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Bolganone",
        "faith": "Recover"
      },
      "A": {
        "reason": "Ragnarok"
      }
    },
    "gifts": [
      "Blue Cheese",
      "Legend of Chivalry",
      "Training Weight",
      "Whetstone"
    ],
    "dislikedGifts": [
      "Gemstone Beads",
      "Armored Bear Stuffy",
      "Arithmetic Textbook"
    ],
    "lostItems": [
      "Weathered Cloak",
      "Letter to Rhea",
      "Badge of Graduation"
    ],
    "birthday": {
      "month": "Horsebow Moon",
      "day": 15,
      "year": 1152
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Rose Petal Blend"
      ],
      "topics": [
        "A dinner invitation",
        "Gardening mishaps",
        "Strange fish in the pond",
        "A new gambit",
        "Hopes for your future",
        "Tell me about yourself",
        "A strong battalion",
        "I heard some gossip",
        "Thanks for everything",
        "A word of advice",
        "I'm counting on you",
        "The existence of Crests",
        "Academy memories",
        "Likable allies",
        "The ideal relationship",
        "Capable comrades",
        "Mighty weapons",
        "The last battle",
        "Classes you might enjoy",
        "Monastery security",
        "Working hours for guards",
        "Close calls",
        "Our first meeting",
        "Working together",
        "Cooking mishaps",
        "Past laughs",
        "You seem well",
        "Equipment upkeep",
        "Potential training partners",
        "You're doing great work",
        "Evaluating allies",
        "School days",
        "Your ambitions",
        "Exploring the monastery",
        "Shareable snacks",
        "Food in the dining hall",
        "Someone you look up to"
      ]
    }
  },
  "claude": {
    "growthRates": {
      "hp": 35,
      "str": 40,
      "mag": 25,
      "dex": 60,
      "spd": 55,
      "lck": 45,
      "def": 30,
      "res": 25,
      "cha": 55
    },
    "skills": {
      "sword": {
        "level": "E+",
        "growth": 1
      },
      "lance": {
        "level": "E",
        "growth": -1
      },
      "axe": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "bow": {
        "level": "D",
        "growth": 1
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": 0
      },
      "faith": {
        "level": "E",
        "growth": -1
      },
      "authority": {
        "level": "D",
        "growth": 1
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E+",
        "growth": 1
      },
      "flying": {
        "level": "E+",
        "growth": 1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Wind",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Sagittae",
        "faith": "Recover"
      },
      "B": {
        "reason": "Cutting Gale"
      },
      "A": {
        "reason": "Excalibur",
        "faith": "Silence"
      }
    },
    "gifts": [
      "Board Game",
      "Exotic Spices",
      "Riding Boots",
      "Book of Crest Designs"
    ],
    "dislikedGifts": [
      "Book of Sheet Music",
      "Blue Cheese"
    ],
    "lostItems": [
      "Leather Bow Sheath",
      "Mild Stomach Poison",
      "Board Game Piece"
    ],
    "birthday": {
      "month": "Blue Sea Moon",
      "day": 24,
      "year": 1162
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Almyran Pine Needles",
        "Chamomile"
      ],
      "topics": [
        "A dinner invitation",
        "A new gambit",
        "A place you'd like to visit",
        "A strong battalion",
        "A word of advice",
        "Books you've read recently",
        "Capable comrades",
        "Celebrations",
        "Children at the market",
        "Classes you might enjoy",
        "Close calls",
        "Equipment upkeep",
        "Evaluating allies",
        "Exploring the Monastery",
        "Fodlan's future",
        "Food in the Dining Hall",
        "Gardening mishaps",
        "Gifts you'd like to receive",
        "Guessing someone's age",
        "Hopes for your future",
        "I heard some gossip",
        "I'm counting on you",
        "Likeable allies",
        "Mighty weapons",
        "Monastery mysteries",
        "Monastery security",
        "Our first meeting",
        "Overcoming weaknesses",
        "Past laughs",
        "Perfect recipes",
        "Plans for the future",
        "Reliable allies",
        "School days",
        "Strange fish in the pond",
        "Tell me about yourself",
        "Thanks for everything",
        "The existence of Crests",
        "The ideal professor",
        "The last battle",
        "The Library's collection",
        "Things that bother you",
        "Working together",
        "You seem different",
        "You seem well",
        "Your ambitions"
      ]
    }
  },
  "constance": {
    "growthRates": {
      "hp": 20,
      "str": 20,
      "mag": 60,
      "dex": 30,
      "spd": 35,
      "lck": 15,
      "def": 15,
      "res": 30,
      "cha": 25
    },
    "skills": {
      "sword": {
        "level": "E+",
        "growth": 1
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "E",
        "growth": -1
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "reason": {
        "level": "D+",
        "growth": 1
      },
      "faith": {
        "level": "E",
        "growth": 1
      },
      "authority": {
        "level": "D",
        "growth": 1
      },
      "heavyArmor": {
        "level": "E",
        "growth": -1
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "D",
        "growth": 1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Fire",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Sagittae",
        "faith": "Ward"
      },
      "B": {
        "reason": "Fimbulvetr",
        "faith": "Rescue"
      },
      "A": {
        "reason": "Bolting",
        "faith": "Abraxas"
      },
      "A+": {
        "reason": "Agnea's Arrow"
      }
    },
    "gifts": [
      "Arithmetic Textbook",
      "Book of Crest Designs",
      "Tea Leaves",
      "Lily of the Valley"
    ],
    "dislikedGifts": [
      "Blue Cheese",
      "Exotic Spices"
    ],
    "lostItems": [
      "Nimbus Charm",
      "Repellent Powder"
    ],
    "birthday": {
      "month": "Lone Moon",
      "day": 20,
      "year": 1161
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Bergamot",
        "Rose Petal Blend",
        "Sweet-Apple Blend",
        "Albinean Berry Blend"
      ],
      "topics": [
        "A dinner invitation",
        "Fodlan's future",
        "Shareable snacks",
        "A new gambit",
        "Food in the dining hall",
        "Thanks for everything",
        "Books you've read recently",
        "Gifts you'd like to receive",
        "The existence of Crests",
        "Capable comrades",
        "Hopes for your future",
        "The last battle",
        "Cats",
        "I heard some gossip",
        "The library's collection",
        "Classes you might enjoy",
        "Magical innovations",
        "The opera",
        "Close calls",
        "Monastery mysteries",
        "The view from the bridge",
        "Equipment upkeep",
        "Our first meeting",
        "Things you find romantic",
        "Exploring the monastery",
        "Overcoming weaknesses",
        "Working together",
        "Favorite sweets",
        "Relaxing at the sauna",
        "First crushes",
        "Reliable allies"
      ]
    }
  },
  "cyril": {
    "growthRates": {
      "hp": 35,
      "str": 20,
      "mag": 15,
      "dex": 40,
      "spd": 40,
      "lck": 30,
      "def": 10,
      "res": 10,
      "cha": 15
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "E",
        "growth": 1
      },
      "axe": {
        "level": "D+",
        "growth": 1
      },
      "bow": {
        "level": "D",
        "growth": 1
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": -1
      },
      "faith": {
        "level": "E",
        "growth": -1
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": 1
      },
      "flying": {
        "level": "E",
        "growth": 1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Wind",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Cutting Gale",
        "faith": "Recover"
      }
    },
    "gifts": [
      "Hunting Dagger",
      "Smoked Meat",
      "Watering Can",
      "Baby's Breath"
    ],
    "dislikedGifts": [
      "The History of Fodlan",
      "Legends of Chivalry",
      "Monarch Studies Book"
    ],
    "lostItems": [
      "Well-Used Hatchet",
      "Portrait of Rhea",
      "Old Cleaning Cloth"
    ],
    "birthday": {
      "month": "Wyvern Moon",
      "day": 25,
      "year": 1165
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Almyran Pine Needles"
      ],
      "topics": [
        "A dinner invitation",
        "Gifts you'd like to receive",
        "Tell me about yourself",
        "Cats",
        "Guessing someone's age",
        "Thanks for everything",
        "Children at the market",
        "I heard some gossip",
        "The view from the bridge",
        "Classes you might enjoy",
        "I'm counting on you",
        "Things that bother you",
        "Close calls",
        "Lady Rhea",
        "Working hours for guards",
        "Cute monks",
        "Likable allies",
        "You seem different",
        "Equipment upkeep",
        "Monastery security",
        "You seem well",
        "Exploring the monastery",
        "Overcoming weaknesses",
        "You're doing great work",
        "Favorite sweets",
        "Perfect recipes",
        "Your ambitions",
        "Food in the dining hall",
        "Shareable snacks",
        "Gardening mishaps",
        "Strange fish in the pond"
      ]
    }
  },
  "dedue": {
    "growthRates": {
      "hp": 60,
      "str": 50,
      "mag": 15,
      "dex": 30,
      "spd": 20,
      "lck": 25,
      "def": 50,
      "res": 10,
      "cha": 30
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "E+",
        "growth": 1
      },
      "axe": {
        "level": "D+",
        "growth": 1
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E+",
        "growth": 1
      },
      "reason": {
        "level": "E",
        "growth": 0
      },
      "faith": {
        "level": "E",
        "growth": -1
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "D",
        "growth": 1
      },
      "riding": {
        "level": "E",
        "growth": -1
      },
      "flying": {
        "level": "E",
        "growth": -1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Fire",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Bolganone",
        "faith": "Recover"
      },
      "B": {
        "reason": "Ragnarok"
      }
    },
    "gifts": [
      "Exotic Spices",
      "Floral Adornment",
      "Watering Can"
    ],
    "dislikedGifts": [
      "Book of Sheet Music",
      "The History of Fodlan"
    ],
    "lostItems": [
      "Gold Earring",
      "Gardening Sheers",
      "Iron Cooking Pot"
    ],
    "birthday": {
      "month": "Verdant Rain Moon",
      "day": 31,
      "year": 1161
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Cinnamon Blend",
        "Four-Spice Blend",
        "Ginger Tea"
      ],
      "topics": [
        "A dinner invitation",
        "Food in the dining hall",
        "Shareable snacks",
        "A strong battalion",
        "Gardening mishaps",
        "Someone you look up to",
        "A word of advice",
        "Gifts you'd like to receive",
        "Strange fish in the pond",
        "Capable comrades",
        "I'm counting on you",
        "Thanks for everything",
        "Cooking mishaps",
        "Monastery security",
        "The last battle",
        "Dimitri",
        "Our first meeting",
        "Working hours for guards",
        "Equipment upkeep",
        "Overcoming weaknesses",
        "Working together",
        "Exploring the monastery",
        "Perfect recipes",
        "Your ambitions",
        "Favorite sweets",
        "Potential training partners",
        "Fodlan's future",
        "Reliable allies"
      ]
    }
  },
  "dimitri": {
    "growthRates": {
      "hp": 55,
      "str": 60,
      "mag": 20,
      "dex": 50,
      "spd": 50,
      "lck": 25,
      "def": 40,
      "res": 20,
      "cha": 55
    },
    "skills": {
      "sword": {
        "level": "E+",
        "growth": 1
      },
      "lance": {
        "level": "D+",
        "growth": 1
      },
      "axe": {
        "level": "E",
        "growth": -1
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": -1
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "D",
        "growth": 1
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "D",
        "growth": 0,
        "buddingTalent": true
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Thunder",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Thoron",
        "faith": "Recover"
      },
      "A": {
        "faith": "Aura"
      }
    },
    "gifts": [
      "Ceremonial Sword",
      "Riding Boots",
      "Training Weight",
      "Whetstone"
    ],
    "dislikedGifts": [
      "Gemstone Beads",
      "Armored Bear Stuffy",
      "Book of Sheet Music"
    ],
    "lostItems": [
      "Black Leather Gloves",
      "Dulled Longsword",
      "Training Logbook"
    ],
    "birthday": {
      "month": "Ethereal Moon",
      "day": 20,
      "year": 1162
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Chamomile"
      ],
      "topics": [
        "A new gambit",
        "A place you'd like to visit",
        "A strong battalion",
        "A word of advice",
        "Books you've read recently",
        "Children at the market",
        "Close calls",
        "Cooking mishaps",
        "Equipment upkeep",
        "Evaluating allies",
        "Exploring the monastery",
        "Fódlan's future",
        "I'm counting on you",
        "Mighty weapons",
        "Monastery rules",
        "Monastery security",
        "Our first meeting",
        "Overcoming weaknesses",
        "Past laughs",
        "Potential training partners",
        "Reliable allies",
        "School days",
        "Someone you look up to",
        "Sturdy weapons",
        "Tell me about yourself",
        "Thanks for everything",
        "The ideal professor",
        "The last battle",
        "The library's collection",
        "The view from the bridge",
        "Things that bother you",
        "Working hours for guards",
        "Working together",
        "You seem well",
        "You're doing great work",
        "Your ambitions"
      ]
    }
  },
  "dorothea": {
    "growthRates": {
      "hp": 40,
      "str": 20,
      "mag": 40,
      "dex": 45,
      "spd": 40,
      "lck": 35,
      "def": 15,
      "res": 35,
      "cha": 40
    },
    "skills": {
      "sword": {
        "level": "E+",
        "growth": 1
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "E",
        "growth": 0
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "D",
        "growth": 1
      },
      "faith": {
        "level": "E",
        "growth": -1,
        "buddingTalent": true
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": -1
      },
      "flying": {
        "level": "E",
        "growth": -1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Thunder",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Thoron",
        "faith": "Physic"
      },
      "B": {
        "reason": "Sagittae"
      },
      "A": {
        "reason": "Meteor"
      },
      "A+": {
        "reason": "Agnea's Arrow"
      }
    },
    "gifts": [
      "Book of Sheet Music",
      "Gemstone Beads",
      "Stylish Hair Clip"
    ],
    "dislikedGifts": [
      "Goddess Statuette",
      "Floral Adornment"
    ],
    "lostItems": [
      "Silver Brooch",
      "Songstress Poster",
      "Lovely Comb"
    ],
    "birthday": {
      "month": "Horsebow Moon",
      "day": 29,
      "year": 1161
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Sweet-Apple Blend",
        "Albinean Berry Blend"
      ],
      "topics": [
        "A dinner invitation",
        "I heard some gossip",
        "Tell me about yourself",
        "A new gambit",
        "I'm counting on you",
        "Thanks for everything",
        "Books you've read recently",
        "Likable allies",
        "The courtyard couple",
        "Close calls",
        "Monastery rules",
        "The ideal relationship",
        "Cute monks",
        "Monastery security",
        "The melody of words",
        "Dining partners",
        "Our first meeting",
        "The opera",
        "Dreamy knights",
        "Past laughs",
        "Things that bother you",
        "Evaluating allies",
        "Plans for the future",
        "Things you find romantic",
        "Exploring the monastery",
        "Potential training partners",
        "Working hours for guards",
        "Fashion",
        "Relaxing at the sauna",
        "Working together",
        "First crushes",
        "School days",
        "You seem different",
        "Gifts you'd like to receive",
        "School uniforms",
        "You seem well",
        "Heart-racing memories",
        "Someone you look up to",
        "You're doing great work",
        "Hopes for your future",
        "Strange fish in the pond"
      ]
    }
  },
  "edelgard": {
    "growthRates": {
      "hp": 40,
      "str": 55,
      "mag": 45,
      "dex": 45,
      "spd": 40,
      "lck": 30,
      "def": 35,
      "res": 35,
      "cha": 60
    },
    "skills": {
      "sword": {
        "level": "E+",
        "growth": 1
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "D",
        "growth": 1
      },
      "bow": {
        "level": "E",
        "growth": -1
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "faith": {
        "level": "E",
        "growth": -1
      },
      "authority": {
        "level": "D",
        "growth": 1
      },
      "heavyArmor": {
        "level": "D",
        "growth": 1
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Fire",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Bolganone",
        "faith": "Recover"
      },
      "B": {
        "reason": "Luna Λ",
        "faith": "Seraphim"
      },
      "A": {
        "reason": "Hades Ω"
      }
    },
    "gifts": [
      "Armored Bear Stuffy",
      "Board Game",
      "Monarch Studies Book",
      "Carnation"
    ],
    "dislikedGifts": [
      "Goddess Statuette",
      "Ceremonial Sword"
    ],
    "lostItems": [
      "Eastern Porcelain",
      "Time-worn Quill Pen",
      "White Glove"
    ],
    "birthday": {
      "month": "Garland Moon",
      "day": 22,
      "year": 1162
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Bergamot"
      ],
      "topics": [
        "A new gambit",
        "A strong battalion",
        "A word of advice",
        "Books you've read recently",
        "Capable comrades",
        "Cats",
        "Classes you might enjoy",
        "Close calls",
        "Dreaming of lazy days",
        "Equipment upkeep",
        "Evaluating allies",
        "Exploring the Monastery",
        "Favorite sweets",
        "Fodlan's future",
        "Gifts you'd like to recieve",
        "Hopes for your future",
        "I heard some gossip",
        "I'm counting on you",
        "Monastery mysteries",
        "Monastery security",
        "Our first meeting",
        "Overcoming weaknesses",
        "Past laughs",
        "Plans for the future",
        "Reliable allies",
        "School days",
        "School uniforms",
        "Tell me about yourself",
        "Thanks for everything",
        "The existence of Crests",
        "The ideal professor",
        "The last battle",
        "The Library's collection",
        "The opera",
        "The view from the bridge",
        "Things that bother you",
        "Things you find romantic",
        "You seem different",
        "You're doing great work",
        "Your ambitions"
      ]
    }
  },
  "felix": {
    "growthRates": {
      "hp": 45,
      "str": 55,
      "mag": 30,
      "dex": 45,
      "spd": 55,
      "lck": 40,
      "def": 30,
      "res": 20,
      "cha": 30
    },
    "skills": {
      "sword": {
        "level": "D",
        "growth": 1
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "E",
        "growth": 0
      },
      "bow": {
        "level": "E+",
        "growth": 1
      },
      "brawl": {
        "level": "E+",
        "growth": 1
      },
      "reason": {
        "level": "E",
        "growth": -1,
        "buddingTalent": true
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "E",
        "growth": -1
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Thunder",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Thoron",
        "faith": "Recover"
      },
      "B": {
        "faith": "Restore"
      }
    },
    "gifts": [
      "Ceremonial Sword",
      "Hunting Dagger",
      "Smoked Meat",
      "Training Weight"
    ],
    "dislikedGifts": [
      "Legends of Chivalry",
      "Armored Bear Stuffy",
      "Tasty Bake Treat"
    ],
    "lostItems": [
      "Black Iron Spur",
      "Sword Belt Fragment",
      "Toothed Dagger"
    ],
    "birthday": {
      "month": "Pegasus Moon",
      "day": 20,
      "year": 1163
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Almyran Pine Needles",
        "Four-Spice Blend"
      ],
      "topics": [
        "A new gambit",
        "Exploring the monastery",
        "Reliable allies",
        "A new sword technique",
        "Food in the dining hall",
        "Shareable snacks",
        "A strong battalion",
        "I'm counting on you",
        "Someone you look up to",
        "Capable comrades",
        "Mighty weapons",
        "The last battle",
        "Cats",
        "Monastery security",
        "The opera",
        "Children at the market",
        "Our first meeting",
        "Working together",
        "Classes you might enjoy",
        "Overcoming weaknesses",
        "You're doing great work",
        "Equipment upkeep",
        "Plans for the future",
        "Your ambitions",
        "Evaluating allies",
        "Potential training partners"
      ]
    }
  },
  "ferdinand": {
    "growthRates": {
      "hp": 50,
      "str": 45,
      "mag": 20,
      "dex": 40,
      "spd": 50,
      "lck": 40,
      "def": 35,
      "res": 20,
      "cha": 40
    },
    "skills": {
      "sword": {
        "level": "E+",
        "growth": 1
      },
      "lance": {
        "level": "D",
        "growth": 1
      },
      "axe": {
        "level": "E+",
        "growth": 1
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": 0
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "riding": {
        "level": "D",
        "growth": 1
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Thunder",
        "faith": "Heal"
      },
      "D+": {
        "reason": "Fire",
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Thoron",
        "faith": "Ward"
      },
      "B": {
        "reason": "Bolganone",
        "faith": "Restore"
      }
    },
    "gifts": [
      "Riding Boots",
      "Tea Leaves",
      "Whetstone"
    ],
    "dislikedGifts": [
      "Blue Cheese",
      "Coffee Beans"
    ],
    "lostItems": [
      "Maintenance Oil",
      "Agricultural Survey",
      "Bag of Tea Leaves"
    ],
    "birthday": {
      "month": "Great Tree Moon",
      "day": 30,
      "year": 1162
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Almyran Pine Needles",
        "Southern Fruit Blend",
        "Seiros Tea"
      ],
      "topics": [
        "A dinner invitation",
        "Food in the dining hall",
        "Tell me about yourself",
        "A strong battalion",
        "Gifts you'd like to receive",
        "Thanks for everything",
        "A word of advice",
        "Guessing someone's age",
        "The existence of Crests",
        "Capable comrades",
        "Heart-racing memories",
        "The ideal professor",
        "Children at the market",
        "Hopes for your future",
        "The ideal relationship",
        "Classes you might enjoy",
        "I heard some gossip",
        "The last battle",
        "Close calls",
        "I'm counting on you",
        "The meaning of nobility",
        "Cooking mishaps",
        "Likable allies",
        "The opera",
        "Cute monks",
        "Mighty weapons",
        "Things that bother you",
        "Dining partners",
        "Monastery rules",
        "Things you find romantic",
        "Dreamy knights",
        "Past laughs",
        "Working together",
        "Equipment upkeep",
        "Plans for the future",
        "You seem different",
        "Evaluating allies",
        "Potential training partners",
        "You seem well",
        "Exploring the monastery",
        "Relaxing at the sauna",
        "You're doing great work",
        "Fashion",
        "School days",
        "Your ambitions",
        "First crushes",
        "School uniforms",
        "Fodlan's future",
        "Someone you look up to"
      ]
    }
  },
  "flayn": {
    "growthRates": {
      "hp": 25,
      "str": 25,
      "mag": 55,
      "dex": 45,
      "spd": 35,
      "lck": 15,
      "def": 25,
      "res": 50,
      "cha": 45
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "C+",
        "growth": 1
      },
      "axe": {
        "level": "E",
        "growth": 0
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "faith": {
        "level": "C+",
        "growth": 1
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": -1
      },
      "riding": {
        "level": "E",
        "growth": -1
      },
      "flying": {
        "level": "D",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Wind",
        "faith": "Heal"
      },
      "D+": {
        "reason": "Fire",
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Cutting Gale",
        "faith": "Restore"
      },
      "B": {
        "faith": "Rescue"
      },
      "A": {
        "reason": "Excalibur",
        "faith": "Fortify"
      }
    },
    "gifts": [
      "Armored Bear Stuffy",
      "Dapper Handkerchief",
      "Stylish Hair Clip",
      "Tasty Baked Treat",
      "Forget-me-nots"
    ],
    "dislikedGifts": [
      "Whetstone",
      "Blue Cheese"
    ],
    "lostItems": [
      "Antique Clasp",
      "Old Map of Enbarr",
      "Dusty Book of Fables"
    ],
    "birthday": {
      "month": "Blue Sea Moon",
      "day": 12
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Sweet-Apple Blend",
        "Crescent-Moon Tea",
        "Almond Blend"
      ],
      "topics": [
        "A dinner invitation",
        "Gifts you'd like to receive",
        "Tell me about yourself",
        "A word of advice",
        "Guessing someone's age",
        "Thanks for everything",
        "Books you've read recently",
        "Heart-racing memories",
        "The courtyard couple",
        "Cats",
        "Hopes for your future",
        "The ideal professor",
        "Children at the market",
        "I heard some gossip",
        "The ideal relationship",
        "Close calls",
        "I'm counting on you",
        "The library's collection",
        "Cooking mishaps",
        "Likable allies",
        "The opera",
        "Cute monks",
        "Our first meeting",
        "The view from the bridge",
        "Dining partners",
        "Past laughs",
        "Things that bother you",
        "Dreamy knights",
        "Perfect recipes",
        "Things you find romantic",
        "Favorite sweets",
        "Plans for the future",
        "Working together",
        "First crushes",
        "Potential training partners",
        "You seem well",
        "Fish and the sea",
        "School days",
        "You're doing great work",
        "Fodlan's future",
        "Shareable snacks",
        "Gardening mishaps",
        "Strange fish in the pond"
      ]
    }
  },
  "gilbert": {
    "growthRates": {
      "hp": 55,
      "str": 45,
      "mag": 20,
      "dex": 45,
      "spd": 30,
      "lck": 15,
      "def": 45,
      "res": 10,
      "cha": 35
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "B+",
        "growth": 1
      },
      "axe": {
        "level": "B+",
        "growth": 1
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": 0
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "D+",
        "growth": 0
      },
      "heavyArmor": {
        "level": "B",
        "growth": 1
      },
      "riding": {
        "level": "C",
        "growth": 1
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Thunder",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Thoron",
        "faith": "Ward"
      }
    },
    "gifts": [
      "Ceremonial Sword",
      "Fishing Float",
      "Goddess Statuette"
    ],
    "dislikedGifts": [
      "Tasty Baked Treat",
      "Dapper Handkerchief"
    ],
    "lostItems": [
      "Noseless Puppet",
      "Carving Hammer",
      "Silver Necklace"
    ],
    "birthday": {
      "month": "Guardian Moon",
      "day": 26,
      "year": 1124
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Almond Blend",
        "Lavender Blend"
      ],
      "topics": [
        "A new gambit",
        "Fodlan's future",
        "Someone you look up to",
        "A place you'd like to visit",
        "I'm counting on you",
        "Strange fish in the pond",
        "A strong battalion",
        "Mighty weapons",
        "Thanks for everything",
        "A word of advice",
        "Monastery rules",
        "The ideal professor",
        "Books you've read recently",
        "Monastery security",
        "The last battle",
        "Capable comrades",
        "Overcoming weaknesses",
        "The library's collection",
        "Children at the market",
        "Perfect recipes",
        "Wood carving",
        "Equipment upkeep",
        "Potential training partners",
        "Working hours for guards",
        "Evaluating allies",
        "Reliable allies",
        "Working together",
        "Favorite sweets",
        "Shareable snacks",
        "Your ambitions"
      ]
    }
  },
  "hanneman": {
    "growthRates": {
      "hp": 40,
      "str": 30,
      "mag": 55,
      "dex": 45,
      "spd": 20,
      "lck": 35,
      "def": 25,
      "res": 40,
      "cha": 35
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "E",
        "growth": 0
      },
      "bow": {
        "level": "C+",
        "growth": 1
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "B",
        "growth": 1
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "D",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": -1
      },
      "riding": {
        "level": "D",
        "growth": 1
      },
      "flying": {
        "level": "E",
        "growth": -1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Wind",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Sagittae",
        "faith": "Recover"
      },
      "B": {
        "reason": "Thoron",
        "faith": "Ward"
      },
      "A": {
        "reason": "Ragnarok"
      },
      "A+": {
        "reason": "Meteor"
      }
    },
    "gifts": [
      "Arithmetic Textbook",
      "Book of Crest Designs",
      "Dapper Handkerchief",
      "Tea Leaves"
    ],
    "dislikedGifts": [
      "Blue Cheese",
      "Exotic Spices"
    ],
    "lostItems": [
      "Lens Cloth",
      "Hammer and Chisel",
      "Sketch of a Sigil"
    ],
    "birthday": {
      "month": "Pegasus Moon",
      "day": 8,
      "year": 1129
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Bergamot",
        "Sweet-Apple Blend",
        "Honeyed-Fruit Blend",
        "Cinnamon Blend"
      ],
      "topics": [
        "A dinner invitation",
        "Gifts you'd like to receive",
        "School days",
        "A new gambit",
        "Heart-racing memories",
        "Shareable snacks",
        "A place you'd like to visit",
        "Hopes for your future",
        "Tell me about yourself",
        "A word of advice",
        "I heard some gossip",
        "Thanks for everything",
        "Books you've read recently",
        "I'm counting on you",
        "The existence of Crests",
        "Capable comrades",
        "Likable allies",
        "The ideal professor",
        "Cooking mishaps",
        "Monastery mysteries",
        "The last battle",
        "Equipment upkeep",
        "Monastery rules",
        "The library's collection",
        "Evaluating allies",
        "Monastery security",
        "Things that bother you",
        "Exploring the monastery",
        "Our first meeting",
        "You seem well",
        "Fashion",
        "Overcoming weaknesses",
        "You're doing great work",
        "Favorite sweets",
        "Past laughs",
        "Your research",
        "Fodlan's future",
        "Plans for the future",
        "Food in the dining hall",
        "Relaxing at the sauna"
      ]
    }
  },
  "hapi": {
    "growthRates": {
      "hp": 35,
      "str": 35,
      "mag": 45,
      "dex": 45,
      "spd": 40,
      "lck": 20,
      "def": 15,
      "res": 45,
      "cha": 25
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "D",
        "growth": 0
      },
      "axe": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": -1
      },
      "reason": {
        "level": "D+",
        "growth": 1
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "E",
        "growth": -1
      },
      "heavyArmor": {
        "level": "E",
        "growth": -1
      },
      "riding": {
        "level": "D",
        "growth": 1
      },
      "flying": {
        "level": "E",
        "growth": 1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Miasma Δ",
        "faith": "Heal"
      },
      "D+": {
        "reason": "Swarm Z",
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Banshee Θ",
        "faith": "Physic"
      },
      "B": {
        "reason": "Death Γ",
        "faith": "Seraphim"
      },
      "A": {
        "reason": "Hades Ω",
        "faith": "Warp"
      }
    },
    "gifts": [
      "Coffee Beans",
      "Exotic Spices",
      "Hunting Dagger",
      "Smoked Meat",
      "Tasty Baked Treat",
      "Pitcher Plant"
    ],
    "dislikedGifts": [
      "Training Weight",
      "Monarch Studies Book",
      "Legend of Chivalry"
    ],
    "lostItems": [
      "Shiny Striated Pebble",
      "Basket of Berries"
    ],
    "birthday": {
      "month": "Guardian Moon",
      "day": 15,
      "year": 1159
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Cinnamon Blend",
        "Dagda Fruit Blend",
        "Four-Spice Blend"
      ],
      "topics": [
        "A dinner invitation",
        "Gardening mishaps",
        "Plans for the future",
        "A place you'd like to visit",
        "Gifts you'd like to receive",
        "Shareable snacks",
        "Cats",
        "Guessing someone's age",
        "Stargazing",
        "Close calls",
        "Heart-racing memories",
        "Tell me about yourself",
        "Cooking mishaps",
        "Hopes for your future",
        "Thanks for everything",
        "Exploring the monastery",
        "Likable allies",
        "Working hours for guards",
        "Favorite sweets",
        "Our first meeting",
        "You seem different",
        "Food in the dining hall",
        "Past laughs",
        "You seem well"
      ]
    }
  },
  "hilda": {
    "growthRates": {
      "hp": 50,
      "str": 45,
      "mag": 25,
      "dex": 30,
      "spd": 50,
      "lck": 35,
      "def": 35,
      "res": 20,
      "cha": 50
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "E+",
        "growth": 1
      },
      "axe": {
        "level": "D",
        "growth": 1
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": 0
      },
      "faith": {
        "level": "E",
        "growth": -1
      },
      "authority": {
        "level": "E",
        "growth": -1
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Thunder",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Thoron",
        "faith": "Recover"
      },
      "A": {
        "reason": "Bolting"
      }
    },
    "gifts": [
      "Armored Bear Stuffy",
      "Book of Sheet Music",
      "Dapper Handkerchief",
      "Gemstone Beads",
      "Stylish Hair Clip",
      "Anemone"
    ],
    "dislikedGifts": [
      "Training Weight",
      "Ancient Coin",
      "Legends of Chivalry"
    ],
    "lostItems": [
      "Handmade Hair Clip",
      "Spotless Bandage",
      "Used Bottle of Perfume"
    ],
    "birthday": {
      "month": "Pegasus Moon",
      "day": 3,
      "year": 1162
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Albinean Berry Blend",
        "Southern Fruit Blend",
        "Rose Petal Blend",
        "Mint Leaves"
      ],
      "topics": [
        "A dinner invitation",
        "Gardening mishaps",
        "School uniforms",
        "A place you'd like to visit",
        "Gifts you'd like to receive",
        "Shareable snacks",
        "Classes you might enjoy",
        "Guessing someone's age",
        "Tell me about yourself",
        "Close calls",
        "Heart-racing memories",
        "Thanks for everything",
        "Cute accessories",
        "Hopes for your future",
        "The courtyard couple",
        "Cute monks",
        "I heard some gossip",
        "The ideal relationship",
        "Dining partners",
        "Likable allies",
        "The opera",
        "Dreamy knights",
        "Our first meeting",
        "Things that bother you",
        "Evaluating allies",
        "Past laughs",
        "Things you find romantic",
        "Fashion",
        "Plans for the future",
        "You seem different",
        "Favorite sweets",
        "Relaxing at the sauna",
        "You seem well",
        "First crushes",
        "Reliable allies",
        "You're doing great work",
        "Food in the dining hall",
        "School days"
      ]
    }
  },
  "hubert": {
    "growthRates": {
      "hp": 35,
      "str": 30,
      "mag": 55,
      "dex": 45,
      "spd": 45,
      "lck": 35,
      "def": 25,
      "res": 40,
      "cha": 35
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "axe": {
        "level": "E",
        "growth": -1
      },
      "bow": {
        "level": "E+",
        "growth": 1
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "D",
        "growth": 1
      },
      "faith": {
        "level": "E",
        "growth": -1
      },
      "authority": {
        "level": "E+",
        "growth": 1
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": -1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Miasma Δ",
        "faith": "Heal"
      },
      "D+": {
        "reason": "Mire B",
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Banshee Θ",
        "faith": "Recover"
      },
      "B": {
        "reason": "Death Γ"
      },
      "A": {
        "reason": "Dark Spikes T"
      }
    },
    "gifts": [
      "Board Game",
      "Coffee Beans",
      "The History of Fodlan"
    ],
    "dislikedGifts": [
      "Legends of Chivalry",
      "Gemstone Beads",
      "Landscape Painting"
    ],
    "lostItems": [
      "Hresvelg Treatise",
      "Noxious Handkerchief",
      "Folding Razor"
    ],
    "birthday": {
      "month": "Great Tree Moon",
      "day": 17,
      "year": 1160
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Dagda Fruit Blend",
        "Cinnamon Blend"
      ],
      "topics": [
        "A new gambit",
        "Fodlan's future",
        "Reliable allies",
        "A place you'd like to visit",
        "Guessing someone's age",
        "Someone you look up to",
        "A strong battalion",
        "I heard some gossip",
        "Successful plots",
        "Books you've read recently",
        "I'm counting on you",
        "The last battle",
        "Capable comrades",
        "Mighty weapons",
        "The library's collection",
        "Close calls",
        "Monastery mysteries",
        "Working together",
        "Equipment upkeep",
        "Monastery rules",
        "Your ambitions",
        "Evaluating allies",
        "Monastery security"
      ]
    }
  },
  "ignatz": {
    "growthRates": {
      "hp": 35,
      "str": 35,
      "mag": 30,
      "dex": 50,
      "spd": 50,
      "lck": 55,
      "def": 25,
      "res": 35,
      "cha": 25
    },
    "skills": {
      "sword": {
        "level": "E+",
        "growth": 1
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "E",
        "growth": 0
      },
      "bow": {
        "level": "D",
        "growth": 1
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "E+",
        "growth": 1
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": -1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Blizzard",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Cutting Gale",
        "faith": "Physic"
      },
      "B": {
        "faith": "Ward"
      },
      "A": {
        "reason": "Fimbulvetr"
      }
    },
    "gifts": [
      "Ancient Coin",
      "Ceremonial Sword",
      "Goddess Statuette",
      "Landscape Painting",
      "Forget-me-nots"
    ],
    "dislikedGifts": [
      "Monarch Studies Book",
      "Training Weight"
    ],
    "lostItems": [
      "Blue Stone",
      "Art Book",
      "Letter to the Goddess"
    ],
    "birthday": {
      "month": "Lone Moon",
      "day": 14,
      "year": 1163
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Dagda Fruit Blend",
        "Seiros Tea",
        "Lavender Blend"
      ],
      "topics": [
        "A place you'd like to visit",
        "Gardening mishaps",
        "Someone you look up to",
        "A word of advice",
        "Gifts you'd like to receive",
        "Strange fish in the pond",
        "Books you've read recently",
        "Guessing someone's age",
        "Tell me about yourself",
        "Capable comrades",
        "I heard some gossip",
        "Thanks for everything",
        "Cats",
        "I'm counting on you",
        "The courtyard couple",
        "Children at the market",
        "Likable allies",
        "The library's collection",
        "Classes you might enjoy",
        "Mixing pigments",
        "The opera",
        "Close calls",
        "Monastery mysteries",
        "The view from the bridge",
        "Cute monks",
        "Monastery rules",
        "Things that bother you",
        "Equipment upkeep",
        "Our first meeting",
        "Working together",
        "Evaluating allies",
        "Overcoming weaknesses",
        "You seem different",
        "Exploring the monastery",
        "Past laughs",
        "You seem well",
        "First crushes",
        "Plans for the future",
        "You're doing great work",
        "Fodlan's future",
        "School days"
      ]
    }
  },
  "ingrid": {
    "growthRates": {
      "hp": 40,
      "str": 35,
      "mag": 35,
      "dex": 40,
      "spd": 60,
      "lck": 45,
      "def": 30,
      "res": 40,
      "cha": 45
    },
    "skills": {
      "sword": {
        "level": "E+",
        "growth": 1
      },
      "lance": {
        "level": "D",
        "growth": 1
      },
      "axe": {
        "level": "E",
        "growth": 0
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": 0
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "D",
        "growth": 1
      },
      "flying": {
        "level": "D",
        "growth": 1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Blizzard",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Thoron",
        "faith": "Physic"
      },
      "B": {
        "faith": "Seraphim"
      },
      "A": {
        "reason": "Fimbulvetr"
      }
    },
    "gifts": [
      "Legend of Chivalry",
      "Riding Boots",
      "Smoked Meat"
    ],
    "dislikedGifts": [
      "Gemstone Beads",
      "Stylish Hair Clip"
    ],
    "lostItems": [
      "Pegasus Horseshoes",
      "Jousting Almanac",
      "Curry Comb"
    ],
    "birthday": {
      "month": "Guardian Moon",
      "day": 4,
      "year": 1163
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Mint Leaves",
        "Chamomile"
      ],
      "topics": [
        "A new gambit",
        "Gifts you'd like to receive",
        "Tell me about yourself",
        "A strong battalion",
        "I'm counting on you",
        "Thanks for everything",
        "A word of advice",
        "Mighty weapons",
        "The existence of Crests",
        "Books you've read recently",
        "Monastery rules",
        "The ideal professor",
        "Cats",
        "Monastery security",
        "The last battle",
        "Classes you might enjoy",
        "Our first meeting",
        "The library's collection",
        "Cooking mishaps",
        "Overcoming weaknesses",
        "The view from the bridge",
        "Dreamy knights",
        "Past laughs",
        "Things you find romantic",
        "Equipment upkeep",
        "Perfect recipes",
        "Working hours for guards",
        "Evaluating allies",
        "Plans for the future",
        "Working together",
        "Exploring the monastery",
        "Potential training partners",
        "You seem well",
        "Favorite sweets",
        "Reliable allies",
        "You're doing great work",
        "First crushes",
        "School days",
        "Your ambitions",
        "Fodlan's future",
        "Shareable snacks",
        "Food for life",
        "Someone you look up to",
        "Strange fish in the pond"
      ]
    }
  },
  "jeritza": {
    "growthRates": {
      "hp": 50,
      "str": 50,
      "mag": 35,
      "dex": 35,
      "spd": 60,
      "lck": 30,
      "def": 40,
      "res": 25,
      "cha": 25
    },
    "skills": {
      "sword": {
        "level": "B+",
        "growth": 1
      },
      "lance": {
        "level": "A+",
        "growth": 1
      },
      "axe": {
        "level": "C+",
        "growth": 0
      },
      "bow": {
        "level": "D",
        "growth": 0
      },
      "brawl": {
        "level": "C+",
        "growth": 1
      },
      "reason": {
        "level": "D",
        "growth": 0
      },
      "faith": {
        "level": "E",
        "growth": -1
      },
      "authority": {
        "level": "B",
        "growth": -1
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "A",
        "growth": 1
      },
      "flying": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Thunder",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Thoron",
        "faith": "Restore"
      },
      "B": {
        "reason": "Death Γ"
      }
    },
    "gifts": [
      "Tasty Baked Treat",
      "Whetstone",
      "Hunting Dagger",
      "Rose"
    ],
    "dislikedGifts": [
      "Monarch Studies Book",
      "Blue Cheese",
      "Book of Crest Designs"
    ],
    "lostItems": [
      "Armor Clasp",
      "Black Hair Tie",
      "Jar of Sweets"
    ],
    "birthday": {
      "month": "Lone Moon",
      "day": 4,
      "year": 1158
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Albinean Berry Blend",
        "Honeyed-Fruit Blend",
        "Southern Fruit Blend"
      ],
      "topics": [
        "A dinner invitation",
        "A new gambit",
        "A strong battalion",
        "Books you've read recently",
        "Capable comrades",
        "Cats",
        "Childhood memories",
        "Children at the market",
        "Classes you might enjoy",
        "Equipment upkeep",
        "Evaluating allies",
        "Exploring the Monastery",
        "Favorite sweets",
        "Food in the dining hall",
        "Hopes for your future",
        "I heard some gossip",
        "Mighty weapons",
        "Monastery security",
        "Our first meeting",
        "Potential training partners",
        "Shareable snacks",
        "Thanks for everything",
        "The last battle",
        "The library's collection",
        "The opera",
        "The view from the bridge",
        "Working together",
        "You seem well",
        "Your ambitions"
      ]
    }
  },
  "leonie": {
    "growthRates": {
      "hp": 40,
      "str": 40,
      "mag": 20,
      "dex": 55,
      "spd": 60,
      "lck": 40,
      "def": 40,
      "res": 15,
      "cha": 40
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "D+",
        "growth": 1
      },
      "axe": {
        "level": "E",
        "growth": 0
      },
      "bow": {
        "level": "E+",
        "growth": 1
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": 0
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E+",
        "growth": 1
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Fire",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Bolganone",
        "faith": "Physic"
      },
      "B": {
        "faith": "Restore"
      },
      "A": {
        "reason": "Ragnarok"
      }
    },
    "gifts": [
      "Fishing Float",
      "Hunting Dagger",
      "Training Weight"
    ],
    "dislikedGifts": [
      "Stylish Hair Clip",
      "Book of Crest Designs"
    ],
    "lostItems": [
      "Hand Drawn Map",
      "Crude Arrowheads",
      "Fur Scarf"
    ],
    "birthday": {
      "month": "Pegasus Moon",
      "day": 21,
      "year": 1160
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Four-Spice Blend",
        "Angelica Tea"
      ],
      "topics": [
        "A dinner invitation",
        "Gifts you'd like to receive",
        "Shareable snacks",
        "A new gambit",
        "Hopes for your future",
        "Someone you look up to",
        "A place you'd like to visit",
        "I heard some gossip",
        "Tell me about yourself",
        "A strong battalion",
        "I'm counting on you",
        "Thanks for everything",
        "A word of advice",
        "Jeralt",
        "The ideal professor",
        "Books you've read recently",
        "Mighty weapons",
        "The last battle",
        "Capable comrades",
        "Monastery mysteries",
        "The view from the bridge",
        "Children at the market",
        "Monastery security",
        "Things that bother you",
        "Classes you might enjoy",
        "Our first meeting",
        "Working together",
        "Close calls",
        "Overcoming weaknesses",
        "You seem different",
        "Equipment upkeep",
        "Past laughs",
        "You seem well",
        "Evaluating allies",
        "Plans for the future",
        "You're doing great work",
        "Exploring the monastery",
        "Potential training partners",
        "Your ambitions",
        "Fodlan's future",
        "Reliable allies",
        "Food in the dining hall",
        "School days"
      ]
    }
  },
  "linhardt": {
    "growthRates": {
      "hp": 30,
      "str": 30,
      "mag": 45,
      "dex": 40,
      "spd": 40,
      "lck": 45,
      "def": 30,
      "res": 45,
      "cha": 20
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "E",
        "growth": -1
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": -1
      },
      "reason": {
        "level": "E+",
        "growth": 1
      },
      "faith": {
        "level": "D+",
        "growth": 1
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Wind",
        "faith": "Heal"
      },
      "D+": {
        "reason": "Fire",
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Cutting Gale",
        "faith": "Physic"
      },
      "B": {
        "reason": "Bolganone",
        "faith": "Restore"
      },
      "A": {
        "reason": "Excalibur",
        "faith": "Warp"
      }
    },
    "gifts": [
      "Book of Crest Designs",
      "Fishing Float",
      "Tasty Baked Treat"
    ],
    "dislikedGifts": [
      "Training Weight",
      "Hunting Dagger"
    ],
    "lostItems": [
      "The Saints Revealed",
      "Feather Pillow",
      "Animated Bait"
    ],
    "birthday": {
      "month": "Red Wolf Moon",
      "day": 7,
      "year": 1163
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Almyran Pine Needles",
        "Angelica Tea"
      ],
      "topics": [
        "A dinner invitation",
        "Gifts you'd like to receive",
        "Thanks for everything",
        "A place you'd like to visit",
        "I heard some gossip",
        "The art of napping",
        "A word of advice",
        "Monastery mysteries",
        "The existence of Crests",
        "Books you've read recently",
        "Our first meeting",
        "The library's collection",
        "Capable comrades",
        "Overcoming weaknesses",
        "The view from the bridge",
        "Cats",
        "Past laughs",
        "Things that bother you",
        "Exploring the monastery",
        "Plans for the future",
        "Working hours for guards",
        "Favorite sweets",
        "Strange fish in the pond",
        "Gardening mishaps",
        "Tell me about yourself"
      ]
    }
  },
  "lorenz": {
    "growthRates": {
      "hp": 55,
      "str": 40,
      "mag": 40,
      "dex": 45,
      "spd": 40,
      "lck": 25,
      "def": 30,
      "res": 40,
      "cha": 35
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "D",
        "growth": 1
      },
      "axe": {
        "level": "E",
        "growth": 0
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": -1
      },
      "reason": {
        "level": "E+",
        "growth": 1
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "D",
        "growth": 1
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Fire",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Sagittae",
        "faith": "Recover"
      },
      "B": {
        "reason": "Ragnarok",
        "faith": "Ward"
      },
      "A": {
        "reason": "Agnea's Arrow"
      }
    },
    "gifts": [
      "Book of Sheet Music",
      "Floral Adornment",
      "Tea Leaves",
      "Rose"
    ],
    "dislikedGifts": [
      "Armored Bear Stuffy",
      "Hunting Dagger",
      "Watering Can"
    ],
    "lostItems": [
      "Artificial Flower",
      "A Treatise on Etiquette",
      "Silk Handkerchief"
    ],
    "birthday": {
      "month": "Garland Moon",
      "day": 13,
      "year": 1161
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Bergamot",
        "Rose Petal Blend",
        "Seiros Tea"
      ],
      "topics": [
        "A dinner invitation",
        "Hopes for your future",
        "Someone you look up to",
        "A new gambit",
        "I'm counting on you",
        "Tell me about yourself",
        "A word of advice",
        "Likable allies",
        "Thanks for everything",
        "Capable comrades",
        "Monastery rules",
        "The existence of Crests",
        "Cute monks",
        "Our first meeting",
        "The ideal professor",
        "Dining partners",
        "Overcoming weaknesses",
        "The ideal relationship",
        "Dreamy knights",
        "Past laughs",
        "The opera",
        "Evaluating allies",
        "Plans for the future",
        "Things that bother you",
        "Exploring the monastery",
        "Relaxing at the sauna",
        "Things you find romantic",
        "Fashion",
        "Reliable allies",
        "Working together",
        "First crushes",
        "Roses",
        "You seem different",
        "Fodlan's future",
        "School days",
        "You seem well",
        "Gifts you'd like to receive",
        "School uniforms",
        "Your ambitions",
        "Heart-racing memories",
        "Shareable snacks"
      ]
    }
  },
  "lysithea": {
    "growthRates": {
      "hp": 20,
      "str": 15,
      "mag": 60,
      "dex": 60,
      "spd": 50,
      "lck": 15,
      "def": 10,
      "res": 25,
      "cha": 25
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": -1,
        "buddingTalent": true
      },
      "lance": {
        "level": "E",
        "growth": -1
      },
      "axe": {
        "level": "E",
        "growth": -1
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "D",
        "growth": 1
      },
      "faith": {
        "level": "E+",
        "growth": 1
      },
      "authority": {
        "level": "E+",
        "growth": 1
      },
      "heavyArmor": {
        "level": "E",
        "growth": -1
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Miasma Δ",
        "faith": "Heal"
      },
      "D+": {
        "reason": "Swarm Z",
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Luna Λ",
        "faith": "Seraphim"
      },
      "B": {
        "reason": "Dark Spikes T",
        "faith": "Warp"
      },
      "A": {
        "reason": "Hades Ω",
        "faith": "Abraxas"
      }
    },
    "gifts": [
      "Arithmetic Textbook",
      "Armored Bear Stuffy",
      "Book of Crest Designs",
      "Tasty Baked Treat"
    ],
    "dislikedGifts": [
      "Training Weight",
      "Legends of Chivalry",
      "Coffee Beans"
    ],
    "lostItems": [
      "Encyclopedia of Sweets",
      "Princess Doll",
      "New Bottle of Perfume"
    ],
    "birthday": {
      "month": "Pegasus Moon",
      "day": 28,
      "year": 1165
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Sweet-Apple Blend",
        "Southern Fruit Blend",
        "Crescent-Moon Tea",
        "Honeyed-Fruit Blend"
      ],
      "topics": [
        "A dinner invitation",
        "Gifts you'd like to receive",
        "School uniforms",
        "A new gambit",
        "Hopes for your future",
        "Shareable snacks",
        "A place you'd like to visit",
        "I heard some gossip",
        "Someone you look up to",
        "Books you've read recently",
        "I'm counting on you",
        "Strange fish in the pond",
        "Capable comrades",
        "Likable allies",
        "Tell me about yourself",
        "Cats",
        "Monastery mysteries",
        "Thanks for everything",
        "Classes you might enjoy",
        "Monastery rules",
        "The existence of Crests",
        "Close calls",
        "Our first meeting",
        "The ideal professor",
        "Cooking mishaps",
        "Overcoming weaknesses",
        "The last battle",
        "Evaluating allies",
        "Past laughs",
        "The library's collection",
        "Fashion",
        "Perfect recipes",
        "The thrill of sweets",
        "Favorite sweets",
        "Plans for the future",
        "Working together",
        "Fodlan's future",
        "Relaxing at the sauna",
        "You seem different",
        "Food in the dining hall",
        "School days",
        "Your ambitions"
      ]
    }
  },
  "manuela": {
    "growthRates": {
      "hp": 50,
      "str": 35,
      "mag": 35,
      "dex": 40,
      "spd": 60,
      "lck": 35,
      "def": 30,
      "res": 25,
      "cha": 50
    },
    "skills": {
      "sword": {
        "level": "C+",
        "growth": 1
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "E",
        "growth": 0
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": -1
      },
      "faith": {
        "level": "B",
        "growth": 1
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "D",
        "growth": 1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Thunder",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Bolganone",
        "faith": "Ward"
      },
      "B": {
        "faith": "Silence"
      },
      "A": {
        "reason": "Bolting",
        "faith": "Warp"
      }
    },
    "gifts": [
      "Blue Cheese",
      "Book of Sheet Music",
      "Gemstone Beads",
      "Goddess Statuette"
    ],
    "dislikedGifts": [
      "Board Game",
      "Riding Boots",
      "Smoked Meat"
    ],
    "lostItems": [
      "Wellness Herbs",
      "Clean Dusting Cloth",
      "Light Purple Veil"
    ],
    "birthday": {
      "month": "Verdant Rain Moon",
      "day": 3
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Mint Leaves",
        "Lavender Blend"
      ],
      "topics": [
        "A dinner invitation",
        "Gardening mishaps",
        "School days",
        "A strong battalion",
        "Gifts you'd like to receive",
        "Shareable snacks",
        "A word of advice",
        "Guessing someone's age",
        "Tell me about yourself",
        "Best performance venues",
        "Heart-racing memories",
        "Thanks for everything",
        "Children at the market",
        "Hopes for your future",
        "The courtyard couple",
        "Classes you might enjoy",
        "I heard some gossip",
        "The ideal professor",
        "Close calls",
        "I'm counting on you",
        "The ideal relationship",
        "Cooking mishaps",
        "Likable allies",
        "The opera",
        "Cute monks",
        "Monastery security",
        "Things that bother you",
        "Dining partners",
        "Our first meeting",
        "Things you find romantic",
        "Dreamy knights",
        "Overcoming weaknesses",
        "Working hours for guards",
        "Exploring the monastery",
        "Past laughs",
        "Working together",
        "Fashion",
        "Perfect recipes",
        "You seem well",
        "Favorite sweets",
        "Plans for the future",
        "You're doing great work",
        "First crushes",
        "Relaxing at the sauna",
        "Food in the dining hall",
        "Reliable allies"
      ]
    }
  },
  "marianne": {
    "growthRates": {
      "hp": 35,
      "str": 20,
      "mag": 50,
      "dex": 40,
      "spd": 40,
      "lck": 35,
      "def": 15,
      "res": 45,
      "cha": 40
    },
    "skills": {
      "sword": {
        "level": "E+",
        "growth": 1
      },
      "lance": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "axe": {
        "level": "E",
        "growth": 0
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": -1
      },
      "reason": {
        "level": "E",
        "growth": 0
      },
      "faith": {
        "level": "D+",
        "growth": 1
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": -1
      },
      "riding": {
        "level": "E",
        "growth": 1
      },
      "flying": {
        "level": "E",
        "growth": 1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Blizzard",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Thoron",
        "faith": "Physic"
      },
      "B": {
        "reason": "Cutting Gale",
        "faith": "Silence"
      },
      "A": {
        "reason": "Fimbulvetr",
        "faith": "Aura"
      }
    },
    "gifts": [
      "Armored Bear Stuffy",
      "Dapper Handkerchief",
      "Floral Adornment",
      "Lily of the Valley"
    ],
    "dislikedGifts": [
      "Hunting Dagger",
      "Smoked Meat"
    ],
    "lostItems": [
      "Bag of Seeds",
      "How to be Tidy",
      "Confessional Letter"
    ],
    "birthday": {
      "month": "Red Wolf Moon",
      "day": 23,
      "year": 1162
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Dagda Fruit Blend",
        "Cinnamon Blend",
        "Lavender Blend"
      ],
      "topics": [
        "A dinner invitation",
        "Gardening mishaps",
        "Strange fish in the pond",
        "A new gambit",
        "Hopes for your future",
        "Tell me about yourself",
        "A word of advice",
        "I heard some gossip",
        "Thanks for everything",
        "Books you've read recently",
        "Likable allies",
        "The existence of Crests",
        "Cats",
        "Monastery mysteries",
        "The ideal professor",
        "Children at the market",
        "Our first meeting",
        "The last battle",
        "Close calls",
        "Overcoming weaknesses",
        "The library's collection",
        "Exploring the monastery",
        "Plans for the future",
        "The view from the bridge",
        "Fodlan's future",
        "Relaxing at the sauna",
        "You seem different",
        "Forest birds",
        "School days"
      ]
    }
  },
  "mercedes": {
    "growthRates": {
      "hp": 30,
      "str": 25,
      "mag": 50,
      "dex": 45,
      "spd": 40,
      "lck": 30,
      "def": 25,
      "res": 45,
      "cha": 40
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": -1
      },
      "lance": {
        "level": "E",
        "growth": -1
      },
      "axe": {
        "level": "E",
        "growth": -1
      },
      "bow": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E+",
        "growth": 1
      },
      "faith": {
        "level": "D",
        "growth": 1
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": -1
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Fire",
        "faith": "Heal"
      },
      "D+": {
        "reason": "Thunder",
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Bolganone",
        "faith": "Physic"
      },
      "B": {
        "faith": "Restore"
      },
      "A": {
        "reason": "Ragnarok",
        "faith": "Fortify"
      }
    },
    "gifts": [
      "Armored Bear Stuffy",
      "Gemstone Beads",
      "Goddess Statuette",
      "Tasty Baked Treat",
      "Lavender"
    ],
    "dislikedGifts": [
      "Whetstone",
      "Ancient Coin",
      "Riding Boots"
    ],
    "lostItems": [
      "Book of Ghost Stories",
      "Fruit Preserves",
      "How to Bake Sweets"
    ],
    "birthday": {
      "month": "Harpstring Moon",
      "day": 27,
      "year": 1157
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Albinean Berry Blend",
        "Southern Fruit Blend",
        "Crescent-Moon Tea"
      ],
      "topics": [
        "A dinner invitation",
        "Food in the dining hall",
        "School uniforms",
        "A place you'd like to visit",
        "Gardening mishaps",
        "Shareable snacks",
        "A word of advice",
        "Ghost stories",
        "Tell me about yourself",
        "Books you've read recently",
        "Gifts you'd like to receive",
        "Thanks for everything",
        "Cats",
        "Heart-racing memories",
        "The courtyard couple",
        "Children at the market",
        "I heard some gossip",
        "The ideal relationship",
        "Cooking mishaps",
        "I'm counting on you",
        "The last battle",
        "Cute monks",
        "Likable allies",
        "The library's collection",
        "Dining partners",
        "Monastery rules",
        "The opera",
        "Dreamy knights",
        "Overcoming weaknesses",
        "Things that bother you",
        "Exploring the monastery",
        "Past laughs",
        "You seem different",
        "Fashion",
        "Perfect recipes",
        "You're doing great work",
        "Favorite sweets",
        "Relaxing at the sauna",
        "First crushes",
        "School days"
      ]
    }
  },
  "petra": {
    "growthRates": {
      "hp": 45,
      "str": 40,
      "mag": 25,
      "dex": 50,
      "spd": 60,
      "lck": 45,
      "def": 30,
      "res": 15,
      "cha": 35
    },
    "skills": {
      "sword": {
        "level": "D+",
        "growth": 1
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "E+",
        "growth": 1
      },
      "bow": {
        "level": "E+",
        "growth": 1
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": -1
      },
      "faith": {
        "level": "E",
        "growth": -1
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "D",
        "growth": 1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Wind",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Sagittae",
        "faith": "Restore"
      }
    },
    "gifts": [
      "Exotic Spices",
      "Hunting Dagger",
      "Smoked Meat",
      "Sunflower"
    ],
    "dislikedGifts": [
      "Arithmetic Textbook",
      "Book of Crest Designs"
    ],
    "lostItems": [
      "Exotic Feather",
      "Small Tanned Hide",
      "Annotated Dictionary"
    ],
    "birthday": {
      "month": "Horsebow Moon",
      "day": 7,
      "year": 1164
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Four-Spice Blend",
        "Ginger Tea"
      ],
      "topics": [
        "A dinner invitation",
        "Guessing someone's age",
        "Someone you look up to",
        "A new gambit",
        "Heart-racing memories",
        "Strange fish in the pond",
        "A place you'd like to visit",
        "Hopes for your future",
        "Swimming in the ocean",
        "A strong battalion",
        "I'm counting on you",
        "Tell me about yourself",
        "A word of advice",
        "Likable allies",
        "Thanks for everything",
        "Books you've read recently",
        "Mighty weapons",
        "The ideal relationship",
        "Capable comrades",
        "Monastery mysteries",
        "The last battle",
        "Cats",
        "Monastery rules",
        "The library's collection",
        "Classes you might enjoy",
        "Monastery security",
        "The view from the bridge",
        "Close calls",
        "Overcoming weaknesses",
        "Things you find romantic",
        "Equipment upkeep",
        "Past laughs",
        "Working hours for guards",
        "Evaluating allies",
        "Plans for the future",
        "Working together",
        "Exploring the monastery",
        "Potential training partners",
        "You seem different",
        "Fashion",
        "Relaxing at the sauna",
        "You seem well",
        "Fodlan's future",
        "School days",
        "You're doing great work",
        "Gifts you'd like to receive",
        "Shareable snacks",
        "Your ambitions"
      ]
    }
  },
  "raphael": {
    "growthRates": {
      "hp": 65,
      "str": 50,
      "mag": 15,
      "dex": 35,
      "spd": 15,
      "lck": 35,
      "def": 45,
      "res": 10,
      "cha": 25
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "E",
        "growth": 0
      },
      "axe": {
        "level": "E+",
        "growth": 1
      },
      "bow": {
        "level": "E",
        "growth": -1
      },
      "brawl": {
        "level": "D",
        "growth": 1
      },
      "reason": {
        "level": "E",
        "growth": -1
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "D",
        "growth": 1
      },
      "riding": {
        "level": "E",
        "growth": -1
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Fire",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Bolganone",
        "faith": "Recover"
      }
    },
    "gifts": [
      "Smoked Meat",
      "Tasty Baked Treat",
      "Training Weight"
    ],
    "dislikedGifts": [
      "Arithmetic Textbook",
      "Book of Crest Designs"
    ],
    "lostItems": [
      "Wooden Button",
      "Burlap Sack of Rocks",
      "Big Spoon"
    ],
    "birthday": {
      "month": "Harpstring Moon",
      "day": 18,
      "year": 1162
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Almond Blend",
        "Ginger Tea"
      ],
      "topics": [
        "A dinner invitation",
        "Gardening mishaps",
        "Strange fish in the pond",
        "A strong battalion",
        "Gifts you'd like to receive",
        "Tell me about yourself",
        "A word of advice",
        "I'm counting on you",
        "Thanks for everything",
        "Cats",
        "Muscle growth",
        "The last battle",
        "Children at the market",
        "Overcoming weaknesses",
        "The opera",
        "Classes you might enjoy",
        "Past laughs",
        "Things that bother you",
        "Close calls",
        "Perfect recipes",
        "Working together",
        "Cooking mishaps",
        "Plans for the future",
        "You seem well",
        "Dining partners",
        "Potential training partners",
        "You're doing great work",
        "Dreamy knights",
        "School days",
        "Your ambitions",
        "Favorite sweets",
        "Shareable snacks",
        "Food in the dining hall",
        "Someone you look up to"
      ]
    }
  },
  "seteth": {
    "growthRates": {
      "hp": 50,
      "str": 45,
      "mag": 35,
      "dex": 50,
      "spd": 50,
      "lck": 25,
      "def": 30,
      "res": 25,
      "cha": 45
    },
    "skills": {
      "sword": {
        "level": "D+",
        "growth": 1
      },
      "lance": {
        "level": "B",
        "growth": 1
      },
      "axe": {
        "level": "B",
        "growth": 1
      },
      "bow": {
        "level": "E",
        "growth": 0
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": 0
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "B",
        "growth": 1
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": -1
      },
      "flying": {
        "level": "C",
        "growth": 1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Wind",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Cutting Gale",
        "faith": "Recover"
      },
      "B": {
        "reason": "Bolganone"
      },
      "A": {
        "reason": "Excalibur"
      }
    },
    "gifts": [
      "Fishing Float",
      "Dapper Handkerchief",
      "The History of Fodlan"
    ],
    "dislikedGifts": [
      "Book of Crest Designs",
      "Legends of Chivalry"
    ],
    "lostItems": [
      "Unfinished Fable",
      "Old Fishing Rod",
      "Snapped Writing Quill"
    ],
    "birthday": {
      "month": "Ethereal Moon",
      "day": 27
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Four-Spice Blend",
        "Ginger Tea",
        "Angelica Tea"
      ],
      "topics": [
        "A dinner invitation",
        "Flayn",
        "Reliable allies",
        "A new gambit",
        "Fodlan's future",
        "Tell me about yourself",
        "A strong battalion",
        "Guessing someone's age",
        "Thanks for everything",
        "A word of advice",
        "Hopes for your future",
        "The ideal professor",
        "Books you've read recently",
        "I heard some gossip",
        "The last battle",
        "Capable comrades",
        "I'm counting on you",
        "The library's collection",
        "Children at the market",
        "Likable allies",
        "The opera",
        "Classes you might enjoy",
        "Mighty weapons",
        "Things that bother you",
        "Close calls",
        "Monastery rules",
        "Working hours for guards",
        "Equipment upkeep",
        "Monastery security",
        "Working together",
        "Evaluating allies",
        "Our first meeting",
        "You're doing great work",
        "Exploring the monastery",
        "Relaxing at the sauna",
        "Your ambitions"
      ]
    }
  },
  "shamir": {
    "growthRates": {
      "hp": 35,
      "str": 40,
      "mag": 20,
      "dex": 55,
      "spd": 40,
      "lck": 55,
      "def": 20,
      "res": 15,
      "cha": 30
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "C+",
        "growth": 1
      },
      "axe": {
        "level": "E",
        "growth": 0
      },
      "bow": {
        "level": "A",
        "growth": 1
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": 0
      },
      "faith": {
        "level": "E",
        "growth": -1
      },
      "authority": {
        "level": "D",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": 0
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Blizzard",
        "faith": "Heal"
      },
      "D+": {
        "reason": "Wind",
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Sagittae",
        "faith": "Recover"
      },
      "A": {
        "reason": "Fimbulvetr"
      }
    },
    "gifts": [
      "Book of Sheet Music",
      "Coffee Beans",
      "Exotic Spices",
      "Hunting Dagger",
      "Sunflower"
    ],
    "dislikedGifts": [
      "Monarch Studies Book",
      "Blue Cheese",
      "Book of Crest Designs"
    ],
    "lostItems": [
      "Bundle of Dry Hemp",
      "Centipede Picture",
      "Animal Bone Dice"
    ],
    "birthday": {
      "month": "Lone Moon",
      "day": 27,
      "year": 1155
    },
    "gender": "F",
    "teatime": {
      "favoriteTeas": [
        "Crescent-Moon Tea",
        "Chamomile"
      ],
      "topics": [
        "A dinner invitation",
        "Gifts you'd like to receive",
        "Strange fish in the pond",
        "A new gambit",
        "Hopes for your future",
        "Survival skills",
        "A place you'd like to visit",
        "I heard some gossip",
        "Tell me about yourself",
        "A strong battalion",
        "I'm counting on you",
        "Thanks for everything",
        "Capable comrades",
        "Mighty weapons",
        "The courtyard couple",
        "Cats",
        "Monastery security",
        "The ideal relationship",
        "Children at the market",
        "Overcoming weaknesses",
        "The last battle",
        "Classes you might enjoy",
        "Past laughs",
        "The view from the bridge",
        "Close calls",
        "Plans for the future",
        "Working together",
        "Equipment upkeep",
        "Potential training partners",
        "You're doing great work",
        "Evaluating allies",
        "Reliable allies",
        "Your ambitions",
        "Food in the dining hall",
        "Shareable snacks"
      ]
    }
  },
  "sylvain": {
    "growthRates": {
      "hp": 55,
      "str": 45,
      "mag": 30,
      "dex": 35,
      "spd": 50,
      "lck": 35,
      "def": 40,
      "res": 25,
      "cha": 40
    },
    "skills": {
      "sword": {
        "level": "E",
        "growth": 0
      },
      "lance": {
        "level": "D",
        "growth": 1
      },
      "axe": {
        "level": "D",
        "growth": 1
      },
      "bow": {
        "level": "E",
        "growth": -1
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "faith": {
        "level": "E",
        "growth": 0
      },
      "authority": {
        "level": "E",
        "growth": 0
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "D",
        "growth": 1
      },
      "flying": {
        "level": "E",
        "growth": 0
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Fire",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Bolganone",
        "faith": "Physic"
      },
      "B": {
        "reason": "Sagittae",
        "faith": "Seraphim"
      },
      "A": {
        "reason": "Ragnarok"
      }
    },
    "gifts": [
      "Board Game",
      "Dapper Handkerchief",
      "Landscape Painting"
    ],
    "dislikedGifts": [
      "Book of Crest Designs",
      "Watering Can",
      "Floral Adornment"
    ],
    "lostItems": [
      "Unused Lipstick",
      "Crumpled Love Letter",
      "The History of Sreng"
    ],
    "birthday": {
      "month": "Garland Moon",
      "day": 5,
      "year": 1160
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Bergamot",
        "Seiros Tea"
      ],
      "topics": [
        "A dinner invitation",
        "Guessing someone's age",
        "Shareable snacks",
        "A place you'd like to visit",
        "Heart-racing memories",
        "Strange fish in the pond",
        "Books you've read recently",
        "Hopes for your future",
        "Tell me about yourself",
        "Capable comrades",
        "I heard some gossip",
        "Thanks for everything",
        "Classes you might enjoy",
        "I'm counting on you",
        "The courtyard couple",
        "Close calls",
        "Likable allies",
        "The ideal relationship",
        "Cooking mishaps",
        "Monastery mysteries",
        "The library's collection",
        "Cute monks",
        "Our first meeting",
        "The opera",
        "Dating escapades",
        "Overcoming weaknesses",
        "The view from the bridge",
        "Dining partners",
        "Past laughs",
        "Things that bother you",
        "Evaluating allies",
        "Perfect recipes",
        "Things you find romantic",
        "Exploring the monastery",
        "Plans for the future",
        "Working together",
        "Fashion",
        "Potential training partners",
        "You seem different",
        "Favorite sweets",
        "Relaxing at the sauna",
        "You seem well",
        "First crushes",
        "Reliable allies",
        "You're doing great work",
        "Food in the dining hall",
        "School days",
        "Gifts you'd like to receive",
        "School uniforms"
      ]
    }
  },
  "yuri": {
    "growthRates": {
      "hp": 30,
      "str": 40,
      "mag": 35,
      "dex": 40,
      "spd": 65,
      "lck": 45,
      "def": 30,
      "res": 35,
      "cha": 50
    },
    "skills": {
      "sword": {
        "level": "D+",
        "growth": 1
      },
      "lance": {
        "level": "E",
        "growth": -1
      },
      "axe": {
        "level": "E",
        "growth": -1
      },
      "bow": {
        "level": "E",
        "growth": 0,
        "buddingTalent": true
      },
      "brawl": {
        "level": "E",
        "growth": 0
      },
      "reason": {
        "level": "E+",
        "growth": 1
      },
      "faith": {
        "level": "D",
        "growth": 1
      },
      "authority": {
        "level": "D+",
        "growth": 1
      },
      "heavyArmor": {
        "level": "E",
        "growth": 0
      },
      "riding": {
        "level": "E",
        "growth": -1
      },
      "flying": {
        "level": "E",
        "growth": -1
      }
    },
    "learnedMagic": {
      "D": {
        "reason": "Wind",
        "faith": "Heal"
      },
      "D+": {
        "faith": "Nosferatu"
      },
      "C": {
        "reason": "Cutting Gale",
        "faith": "Recover"
      },
      "B": {
        "reason": "Sagittae",
        "faith": "Silence"
      },
      "A": {
        "reason": "Excalibur",
        "faith": "Aura"
      }
    },
    "gifts": [
      "Arithmetic Textbook",
      "Board Game",
      "Goddess Statuette",
      "Tasty Baked Treat"
    ],
    "dislikedGifts": [
      "Book of Sheet Music",
      "Riding Boots"
    ],
    "lostItems": [
      "Makeup Brush",
      "Suspicious Dice"
    ],
    "birthday": {
      "month": "Verdant Rain Moon",
      "day": 12,
      "year": 1160
    },
    "gender": "M",
    "teatime": {
      "favoriteTeas": [
        "Albinean Berry Blend",
        "Honeyed-Fruit Blend",
        "Seiros Tea"
      ],
      "topics": [
        "A dinner invitation",
        "Food in the dining hall",
        "School days",
        "A new gambit",
        "Hopes for your future",
        "Shareable snacks",
        "A word of advice",
        "I heard some gossip",
        "Someone you look up to",
        "Books you've read recently",
        "I'm counting on you",
        "Tell me about yourself",
        "Capable comrades",
        "Keeping Abyss safe",
        "Thanks for everything",
        "Cats",
        "Mighty weapons",
        "The existence of Crests",
        "Children at the market",
        "Monastery mysteries",
        "The last battle",
        "Close calls",
        "Monastery security",
        "The library's collection",
        "Cooking mishaps",
        "Our first meeting",
        "The view from the bridge",
        "Equipment upkeep",
        "Past laughs",
        "Things that bother you",
        "Evaluating allies",
        "Perfect recipes",
        "Working hours for guards",
        "Exploring the monastery",
        "Plans for the future",
        "Working together",
        "Fashion",
        "Relaxing at the sauna",
        "Favorite sweets",
        "Reliable allies"
      ]
    }
  }
};
