function isFemaleCharacter(c){return c.id==='byleth'?state.profile.gender==='female':['hapi','constance','lysithea','dorothea','marianne','annette','mercedes','flayn','manuela','edelgard','bernadetta','petra','ingrid','hilda','leonie','catherine','shamir','anna'].includes(c.id);}
function characterBuild(c){
 const b=BUILDS[c.build];
 if(c.id==='byleth'&&state.profile.gender==='female')return {...b,path:['剑客 Lv.5','佣兵 Lv.10','剑圣 Lv.20','涅槃那（剧情）'],note:b.note+' 贝雷丝不能转男性限定的勇者；此处改为剑圣过渡。'};
 if(isFemaleCharacter(c))return {...b,path:b.path.map(p=>p.replace('术士 / 暗主教','术士'))};
 return b;
}
function classNames(step){return step.replace(/\s*Lv\.\d+/g,'').replace(/（[^）]*）/g,'').split(' / ').map(s=>s.trim()).filter(n=>CLASS_CERTIFICATIONS[n]);}
function certificationText(name){const r=CLASS_CERTIFICATIONS[name];return `${name}：${r[0]?`角色 Lv.${r[0]}；`:''}${r[1]}；${r[2]}${r[0]===30?'；指导等级 C 以上':''}${r[3]?`；${r[3]}`:''}`;}
function buildPath(b){return `<div class="path certification-path">${b.path.map(step=>{const names=classNames(step);return `<span><b>${esc(step)}</b>${names.map(n=>`<small>${esc(certificationText(n))}</small>`).join('')}${!names.length?'<small>按队伍需要保留已认证的职业</small>':''}</span>`;}).join('')}</div>`;}
function extraClassRequirements(c,b){
 const existing=new Set(b.path.flatMap(classNames));let text=(c.tip+' '+b.note).replaceAll('暗飞天','暗飞行者');const found=[];
 for(const name of Object.keys(CLASS_CERTIFICATIONS).sort((a,b)=>b.length-a.length))if(text.includes(name)){text=text.replaceAll(name,' ');const restriction=CLASS_CERTIFICATIONS[name][3]||'';if(restriction.includes(isFemaleCharacter(c)?'男性限定':'女性限定'))continue;if(!existing.has(name))found.push(name);}
 return found.length?`<h3>其他建议中提到的职业</h3><div class="path certification-path">${found.map(n=>`<span><small>${esc(certificationText(n))}</small></span>`).join('')}</div>`:'';
}
function facultyStatus(t){
 const ch=state.profile.chapter;
 if(ch>12)return '学院篇参考；战争篇请看高级教练';
 if(ch<3)return '第 3 章完成教职研修任务后开启';
 if(t.dlc&&!state.profile.dlc)return '需要追加内容';
 if(t.from&&ch<t.from)return `第 ${t.from} 章起出现`;
 if(t.until&&ch>t.until)return '本章不提供研修';
 if(t.absent.includes(ch))return '本章不提供研修';
 return '核对当周散步对话';
}
function facultyGuide(){
 const academy=TRAINING_SKILLS.map(skill=>{const xp=['剑术','格斗','指挥'].includes(skill)?'普通 +30；优秀 +45':skill==='信仰'?'普通 +20；优秀 +30；才能绽放后 +30／+45':'普通 +20；优秀 +30';return `<article class="faculty-skill"><h3>${skill}</h3><p class="muted">技能经验：${xp}</p><ul>${FACULTY.filter(t=>t.skills.includes(skill)).map(t=>`<li><strong>${t.name}</strong><small>${facultyStatus(t)}${t.note?' · '+t.note:''}</small></li>`).join('')}</ul></article>`;}).join('');
 const advanced=TRAINING_SKILLS.map(skill=>`<div class="drill-row"><strong>${skill}</strong><p>${ADVANCED_DRILLS.filter(t=>t.slice(1).includes(skill)).map(t=>t[0]).join('、')}</p></div>`).join('');
 return `<section class="faculty-guide" id="faculty-guide"><h2>贝雷特／贝雷丝：技能研修找谁</h2><div class="info">教职研修增加<strong>技能经验</strong>，不会直接增加力量、魔力、技巧等基础属性。第 3 章完成「向优秀的老师学习」相关任务后开启；每次消耗 1 点行动力，每位教师每次散步只能指导一次。普通结果基础 +20，擅长技能 +10；获得「优秀」结果时再乘 1.5，即通常 +30／擅长 +45。两位主角的教师对应表相同。</div><p class="muted">下表为学院篇教师。按当前第 ${state.profile.chapter} 章标注已知缺席情况；导师还须在当周可对话。基础属性请通过升级、职业基础值补正或永久能力道具提升。</p><div class="faculty-grid">${academy}</div><details><summary>战争篇：高级教练对应角色与限制</summary><div class="detail-body"><p>战争篇改为高级教练。下列是各技能可能提供训练的人选，须已加入且该技能等级高于主角；路线、离队与生存情况也会影响可选人。伊艾里扎仅在红花战争篇加入后提供对应训练。安娜和灰狼角色按追加内容解锁情况确认。</p><div class="advanced-drills">${advanced}</div></div></details><details><summary>第 12 章分支造成的研修变化（剧透）</summary><div class="detail-body"><p>若第 11 章选择与教会敌对，随后第 12 章不能接受 NPC 的教职研修；不要只按教师缺席表安排当天行动。</p></div></details><a class="small-link" href="https://serenesforest.net/three-houses/monastery/faculty-training/" target="_blank" rel="noopener noreferrer">教师、技能经验与高级教练来源 ↗</a></section>`;
}
