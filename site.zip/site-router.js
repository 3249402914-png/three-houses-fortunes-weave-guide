'use strict';
(()=>{
const pages=new Set(['home','characters','recruit','training','routes','bonds','calendar','plan','sources','classes','equipment','progress','skills','reference','search']);
const root=document.querySelector('#guide-root');
const visits={houses:{page:'home',scroll:0},weave:{page:'home',scroll:0}};
let controller,game,page,detail='',mountCount=0;
const routeScroll=new Map();let routeDepth=0;
const router=window.GuideRouter={game:'houses',page:'home'};
function readRoute(){
  const parts=location.hash.slice(1).split('/');
  const nextGame=parts[0]==='weave'?'weave':parts[0]==='houses'?'houses':game||'houses';
  const nextPage=parts.length>1?parts[1]:parts[0];
  let nextDetail='';try{nextDetail=decodeURIComponent(parts.slice(2).join('/'));}catch{}
  return {game:nextGame,page:pages.has(nextPage)?nextPage:'home',detail:nextDetail.slice(0,160)};
}
function mount(next,restore=false){
  const changed=game!==next.game;
  if(game){visits[game]={page,detail,scroll:window.scrollY};routeScroll.set(game+'/'+page+'/'+detail,window.scrollY);}
  if(controller&&(changed||page!==next.page||detail!==(next.detail||'')))root.querySelectorAll('dialog[open]').forEach(d=>d.close());
  if(changed){
    controller?.destroy();
    // Replace and render in one synchronous task, so there is no blank frame.
    const content=document.querySelector('#shell-'+next.game).content.cloneNode(true);
    document.documentElement.dataset.game=next.game;
    game=next.game;page=next.page;detail=next.detail||'';Object.assign(router,{game,page,detail});
    root.replaceChildren(content);
    const links=document.createElement('div');links.className='game-links';links.setAttribute('aria-label','游戏专区');
    links.innerHTML=`<button type="button" data-game="houses" ${game==='houses'?'aria-current="true"':''}>火焰纹章 风花雪月</button><button type="button" data-game="weave" ${game==='weave'?'aria-current="true"':''}>火焰纹章 万缕千丝</button>`;
    root.querySelector('.brand').after(links);
    controller=window.GUIDE_APPS[game]();mountCount++;
    updateThemeButton();
  }else if(page!==next.page||detail!==(next.detail||'')){
    page=next.page;detail=next.detail||'';Object.assign(router,{page,detail});window.dispatchEvent(new Event('guide:navigate'));
  }else{controller?.closeNav();}
  document.title=`风花雪月与万缕千丝攻略 · 火焰纹章 ${game==='weave'?'万缕千丝':'风花雪月'}`;
  if(restore)window.scrollTo(0,visits[game].scroll);
}
function move(next,restore=false){
  if(next.game===game&&next.page===page&&(next.detail||'')===detail){controller?.closeNav();return;}
  history.pushState(null,'',`#${next.game}/${next.page}${next.detail?'/'+encodeURIComponent(next.detail):''}`);routeDepth++;
  mount(next,restore);
}
document.addEventListener('click',e=>{
  if(e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;
  const button=e.target.closest('button[data-game]');
  if(button){const g=button.dataset.game;e.preventDefault();move({game:g,page:visits[g].page,detail:visits[g].detail},true);const focusTarget=matchMedia('(max-width:800px)').matches?root.querySelector('#menu'):root.querySelector(`[data-game="${g}"]`);focusTarget.focus({preventScroll:true});return;}
  const anchor=e.target.closest('a[href^="#"]');
  if(!anchor||!root.contains(anchor))return;
  const target=anchor.getAttribute('href').slice(1),parts=target.split('/');let destination;
  if(pages.has(target))destination={game,page:target};
  else if(['houses','weave'].includes(parts[0])&&pages.has(parts[1])){let d='';try{d=decodeURIComponent(parts.slice(2).join('/'));}catch{}destination={game:parts[0],page:parts[1],detail:d};}
  if(!destination)return;
  e.preventDefault();move(destination);root.querySelector('#main').focus({preventScroll:true});
});
window.addEventListener('hashchange',()=>{const next=readRoute();const scroll=routeScroll.get(next.game+'/'+next.page+'/'+next.detail);mount(next);if(scroll!==undefined)window.scrollTo(0,scroll);});
router.go=(g,p,d='')=>{if(['houses','weave'].includes(g)&&pages.has(p)){move({game:g,page:p,detail:d});root.querySelector('#main').focus({preventScroll:true});}};
router.back=()=>{if(routeDepth>0){routeDepth--;history.back();}else router.go(game,'home');};
const initial=readRoute();history.replaceState(null,'',`#${initial.game}/${initial.page}${initial.detail?'/'+encodeURIComponent(initial.detail):''}`);mount(initial);
// Useful for QA without exposing either game's internal data or mutable state.
Object.defineProperty(router,'mountCount',{get:()=>mountCount});
})();
