document.addEventListener('DOMContentLoaded',()=>{
const weave=document.documentElement.dataset.game==='weave';
const links=document.createElement('div');links.className='game-links';links.setAttribute('aria-label','游戏专区');links.innerHTML=`<a href="index.html#home" ${weave?'':'aria-current="true"'}>风花雪月</a><a href="weave.html#home" ${weave?'aria-current="true"':''}>万缕千丝</a>`;document.querySelector('.brand').after(links);
});
