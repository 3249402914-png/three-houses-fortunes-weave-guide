'use strict';
const WEAVE_ROUTES={cai:{name:'凯伊',color:'#8f9b80',team:'Ribeira Winds',focus:'机动与均衡',summary:'适合从移动与队伍位置入手。凯伊的个人技能增加移动力，彼得适合弓战技。'},dietrich:{name:'迪特里希',color:'#9e86a5',team:'House Lamine',focus:'剑术与主动进攻',summary:'偏向剑术与暴击配置。Io 的招募名声门槛较低；注意短时限外传和城内事件。'},theodora:{name:'忒奥多拉',color:'#8c9fae',team:'Megaira’s Beacon',focus:'军团与正面作战',summary:'适合用军团支援队伍，索菲娅为教程招募。出城前核对外传期限与角色离城时间。'},leda:{name:'蕾达',color:'#af8d92',team:'Rose Tempest',focus:'速度与灵活调度',summary:'蕾达速度成长突出。茉莉在本路线的门槛较低，适合补充防守位置。'}};
const WEAVE_STAT_NAMES=['HP','力量','魔力','速度','技巧','防守','魔防','幸运','魅力'];
const WEAVE_SOURCE='https://serenesforest.net/fortunes-weave/';
const WEAVE_BUILDS={
物理:{name:'力量输出',path:['Gladiator','Brigand','Warrior'],focus:'主武器＋步兵；优先保证命中与生存。',tip:'比较力量加成与实际攻击速度；高力量不代表能安全承受敌方反击。'},
高速:{name:'高速进攻',path:['Myrmidon','Shido','Swordmaster'],focus:'剑＋步兵；关注速度、技巧和战技搭配。',tip:'用战斗预览核对追击与反击伤害；不要只依赖暴击率。'},
远程:{name:'远程支援',path:['Hunter','Archer','Sniper'],focus:'弓＋步兵；使用射程优势压低敌方反击风险。',tip:'远程单位也要检查敌方接近后的威胁，留出撤退与治疗的位置。'},
防守:{name:'防线承伤',path:['Soldier','Armored Knight','Dreadnought'],focus:'主武器＋防守；为缺少机动的职业安排接应。',tip:'高防守配置仍需避开魔法和重装特效武器。Goliath 不能转为骑乘或飞行。'},
魔法:{name:'魔法输出',path:['Diviner','Shaman','Ovate'],focus:'魔法熟练度；保留可使用所需法术的职业。',tip:'按队伍需要保留治疗或辅助能力；职业成长只是选择因素之一。'},
支援:{name:'治疗与辅助',path:['Diviner','Priest','Bishop'],focus:'先确认法术与战技覆盖，再补充机动或生存。',tip:'把治疗单位安排在能覆盖多个队友的位置，避免暴露在敌方攻击范围。'}};
function weaveStatus(c,p){const r=c.requirements[p.route];if(!r)return {ok:false,label:'本路线第一部不可招募'};if(p.chapter<r.chapter)return {ok:false,label:`第 ${r.chapter} 章起出现`};if(r.auto)return {ok:true,label:'随剧情加入'};return {ok:true,label:`支援 ${r.support} · 名声 ${r.renown}`};}
function weaveRecruitCheck(c,p,support,renown,extraDone=false){const r=c.requirements[p.route];if(!r)return {pass:false,text:'本路线第一部无法邀请此角色。'};if(p.chapter<r.chapter)return {pass:false,text:`尚未到出现章节：第 ${r.chapter} 章。`};if(r.auto)return {pass:true,text:'本路线随剧情加入，无需检查支援或名声。'};if(!Number.isInteger(support)||support<0||support>3||!Number.isInteger(renown)||renown<0||renown>10)return {pass:false,text:'请输入有效等级：支援 0—3，名声 0—10。'};const missing=[];if(support<r.support)missing.push(`支援还差 ${r.support-support} 级`);if(renown<r.renown)missing.push(`名声还差 ${r.renown-renown} 级`);if(r.extra.length&&!extraDone)missing.push('仍需确认任务／物品条件');return {pass:missing.length===0,text:missing.length?missing.join('；'):'数值与附加条件已满足；确认当前日期能找到角色，再对话邀请。'};}
function weaveValidatePlan(s){return !!s&&s.game==='fortunes-weave'&&s.version===1&&!!s.profile&&!!WEAVE_ROUTES[s.profile.route]&&Number.isInteger(s.profile.chapter)&&s.profile.chapter>=1&&s.profile.chapter<=12&&Array.isArray(s.favorites)&&Array.isArray(s.done)&&typeof s.notes==='string';}
