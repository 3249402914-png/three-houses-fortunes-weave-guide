'use strict';
const WEAVE_CHARACTERS=[
  {
    "id": "cai",
    "en": "Cai",
    "name": "凯伊",
    "house": "cai",
    "role": "物理",
    "growth": [
      45,
      45,
      40,
      45,
      45,
      35,
      35,
      40,
      40
    ],
    "requirements": {
      "cai": {
        "chapter": 1,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      },
      "dietrich": null,
      "theodora": null,
      "leda": null
    },
    "abilities": [
      {
        "name": "Brio",
        "level": "Auto"
      },
      {
        "name": "Flamekeeper",
        "level": "Lv 35"
      }
    ],
    "gift": "Rancid Garum"
  },
  {
    "id": "tialla",
    "en": "Tialla",
    "name": "Tialla",
    "house": "cai",
    "role": "魔法",
    "growth": [
      30,
      25,
      45,
      35,
      40,
      20,
      40,
      50,
      45
    ],
    "requirements": {
      "cai": {
        "chapter": 1,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "完成 Cai 外传",
          "交付 3,000G"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "完成 Cai 外传",
          "交付 3,000G"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "完成 Cai 外传",
          "交付 3,000G"
        ]
      }
    },
    "abilities": [
      {
        "name": "Tactician’s Wit",
        "level": "Auto"
      },
      {
        "name": "Tactician’s Insight",
        "level": "Lv 20"
      },
      {
        "name": "Tactician’s Insight+",
        "level": "Lv 35"
      }
    ],
    "gift": "Ebony/Eastern Board Game"
  },
  {
    "id": "peter",
    "en": "Peter",
    "name": "Peter",
    "house": "cai",
    "role": "远程",
    "growth": [
      40,
      35,
      20,
      45,
      60,
      30,
      25,
      35,
      30
    ],
    "requirements": {
      "cai": {
        "chapter": 1,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      }
    },
    "abilities": [
      {
        "name": "Steady Aim",
        "level": "Auto"
      },
      {
        "name": "Correct for Drift",
        "level": "Lv 20"
      },
      {
        "name": "Correct for Drift+",
        "level": "Lv 35"
      }
    ],
    "gift": null
  },
  {
    "id": "ultand",
    "en": "Ultand",
    "name": "Ultand",
    "house": "cai",
    "role": "物理",
    "growth": [
      45,
      40,
      40,
      35,
      40,
      35,
      45,
      55,
      50
    ],
    "requirements": {
      "cai": {
        "chapter": 6,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 5,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 6,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      }
    },
    "abilities": [
      {
        "name": "Patch Up",
        "level": "Auto"
      },
      {
        "name": "Pray for Safety",
        "level": "Lv 20"
      },
      {
        "name": "Pray for Safety+",
        "level": "Lv 35"
      }
    ],
    "gift": "Rancid Garum"
  },
  {
    "id": "gaitz",
    "en": "Gaitz",
    "name": "Gaitz",
    "house": "other",
    "role": "防守",
    "growth": [
      50,
      50,
      20,
      40,
      45,
      45,
      25,
      40,
      45
    ],
    "requirements": {
      "cai": null,
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "完成 Bertrand 外传，并到第 12 章"
        ]
      },
      "theodora": null,
      "leda": null
    },
    "abilities": [
      {
        "name": "Brave Assist",
        "level": "Auto"
      },
      {
        "name": "Flashing Fang",
        "level": "Lv 20"
      },
      {
        "name": "Flashing Fang+",
        "level": "Lv 35"
      }
    ],
    "gift": "Rancid Garum"
  },
  {
    "id": "jester",
    "en": "Jester",
    "name": "Jester",
    "house": "other",
    "role": "高速",
    "growth": [
      40,
      35,
      15,
      60,
      45,
      35,
      25,
      40,
      40
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "完成三次个人委托"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 6,
        "auto": false,
        "extra": [
          "完成三次个人委托"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "完成三次个人委托"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "完成三次个人委托"
        ]
      }
    },
    "abilities": [
      {
        "name": "Blink of an Eye",
        "level": "Auto"
      },
      {
        "name": "Flickering Edge",
        "level": "Lv 20"
      },
      {
        "name": "Flickering Edge+",
        "level": "Lv 35"
      }
    ],
    "gift": "Legendary Garum"
  },
  {
    "id": "goliath",
    "en": "Goliath",
    "name": "Goliath",
    "house": "other",
    "role": "防守",
    "growth": [
      55,
      60,
      5,
      15,
      30,
      50,
      20,
      35,
      20
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "交付 Giant’s Meat x3"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 6,
        "auto": false,
        "extra": [
          "交付 Giant’s Meat x3"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "交付 Giant’s Meat x3"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "交付 Giant’s Meat x3"
        ]
      }
    },
    "abilities": [
      {
        "name": "Heavyweight Class",
        "level": "Auto"
      },
      {
        "name": "Pin Down",
        "level": "Lv 20"
      },
      {
        "name": "Pin Down+",
        "level": "Lv 35"
      }
    ],
    "gift": "Rancid Garum"
  },
  {
    "id": "dante",
    "en": "Dante",
    "name": "Dante",
    "house": "other",
    "role": "魔法",
    "growth": [
      30,
      30,
      45,
      40,
      40,
      20,
      40,
      45,
      30
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "交付 8,000G"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 2,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 8,000G"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 6,
        "auto": false,
        "extra": [
          "交付 8,000G"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "交付 8,000G"
        ]
      }
    },
    "abilities": [
      {
        "name": "Stage Direction",
        "level": "Auto"
      },
      {
        "name": "Dramatic Effect",
        "level": "Lv 20"
      },
      {
        "name": "Dramatic Effect+",
        "level": "Lv 35"
      }
    ],
    "gift": "Rancid Garum"
  },
  {
    "id": "dietrich",
    "en": "Dietrich",
    "name": "迪特里希",
    "house": "dietrich",
    "role": "高速",
    "growth": [
      50,
      45,
      30,
      50,
      60,
      40,
      30,
      50,
      60
    ],
    "requirements": {
      "cai": null,
      "dietrich": {
        "chapter": 1,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      },
      "theodora": null,
      "leda": null
    },
    "abilities": [
      {
        "name": "Murderous Intent",
        "level": "Auto"
      },
      {
        "name": "Bestial Impulse",
        "level": "Lv 5"
      }
    ],
    "gift": "Pegasus Panorama"
  },
  {
    "id": "fabio",
    "en": "Fabio",
    "name": "Fabio",
    "house": "dietrich",
    "role": "魔法",
    "growth": [
      40,
      25,
      50,
      35,
      40,
      30,
      45,
      35,
      30
    ],
    "requirements": {
      "cai": null,
      "dietrich": {
        "chapter": 1,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      },
      "theodora": null,
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "完成 Dietrich 外传，并到 11 月 4 日",
          "交付高价值物品（归还）"
        ]
      }
    },
    "abilities": [
      {
        "name": "Dark Calling",
        "level": "Auto"
      },
      {
        "name": "Dark Secrets",
        "level": "Lv 20"
      },
      {
        "name": "Dark Secrets+",
        "level": "Lv 35"
      }
    ],
    "gift": "Rare Southern Seeds"
  },
  {
    "id": "esmeralda",
    "en": "Esmeralda",
    "name": "Esmeralda",
    "house": "dietrich",
    "role": "防守",
    "growth": [
      55,
      55,
      20,
      35,
      35,
      45,
      25,
      35,
      30
    ],
    "requirements": {
      "cai": {
        "chapter": 5,
        "support": 2,
        "renown": 7,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      },
      "dietrich": {
        "chapter": 2,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 6,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      }
    },
    "abilities": [
      {
        "name": "Brawn",
        "level": "Auto"
      },
      {
        "name": "Throwing Arm",
        "level": "Lv 20"
      },
      {
        "name": "Throwing Arm+",
        "level": "Lv 35"
      }
    ],
    "gift": "Eastern Earrings"
  },
  {
    "id": "mikaela",
    "en": "Mikaela",
    "name": "Mikaela",
    "house": "dietrich",
    "role": "物理",
    "growth": [
      50,
      45,
      30,
      40,
      35,
      40,
      25,
      30,
      40
    ],
    "requirements": {
      "cai": {
        "chapter": 5,
        "support": 3,
        "renown": 5,
        "auto": false,
        "extra": [
          "交付 3,000G"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 3,000G"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 6,
        "auto": false,
        "extra": [
          "交付 3,000G"
        ]
      }
    },
    "abilities": [
      {
        "name": "Veteran’s Mettle",
        "level": "Auto"
      },
      {
        "name": "Redblade’s Will",
        "level": "Lv 20"
      },
      {
        "name": "Redblade’s Will+",
        "level": "Lv 35"
      }
    ],
    "gift": "Rugged Blade"
  },
  {
    "id": "diego",
    "en": "Diego",
    "name": "Diego",
    "house": "other",
    "role": "远程",
    "growth": [
      45,
      40,
      20,
      45,
      60,
      35,
      20,
      35,
      30
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "完成 Orchel 外传"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "完成 Orchel 外传"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 2,
        "renown": 8,
        "auto": false,
        "extra": [
          "完成 Orchel 外传"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "完成 Orchel 外传"
        ]
      }
    },
    "abilities": [
      {
        "name": "Caretaker",
        "level": "Auto"
      },
      {
        "name": "No Mercy",
        "level": "Lv 20"
      },
      {
        "name": "No Mercy+",
        "level": "Lv 35"
      }
    ],
    "gift": "Decorative Arrows"
  },
  {
    "id": "loretta",
    "en": "Loretta",
    "name": "Loretta",
    "house": "other",
    "role": "高速",
    "growth": [
      35,
      35,
      35,
      55,
      40,
      30,
      40,
      30,
      30
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "交付 Iron Sword x3"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "交付 Iron Sword x3"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 5,
        "auto": false,
        "extra": [
          "交付 Iron Sword x3"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 5,
        "auto": false,
        "extra": [
          "交付 Iron Sword x3"
        ]
      }
    },
    "abilities": [
      {
        "name": "Steadfast",
        "level": "Auto"
      },
      {
        "name": "Peak Form",
        "level": "Lv 20"
      },
      {
        "name": "Peak Form+",
        "level": "Lv 35"
      }
    ],
    "gift": "Portrait of Yu Phas"
  },
  {
    "id": "seteth",
    "en": "Seteth",
    "name": "西提司",
    "house": "other",
    "role": "物理",
    "growth": [
      45,
      45,
      30,
      40,
      45,
      40,
      35,
      30,
      50
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 3,
        "renown": 6,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      },
      "dietrich": null,
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 6,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      }
    },
    "abilities": [
      {
        "name": "Ready for Battle",
        "level": "Auto"
      },
      {
        "name": "Pass Judgement",
        "level": "Lv 20"
      },
      {
        "name": "Pass Judgement+",
        "level": "Lv 35"
      }
    ],
    "gift": "Tales of Adventure"
  },
  {
    "id": "ninae",
    "en": "Ninae",
    "name": "Ninae",
    "house": "other",
    "role": "物理",
    "growth": [
      45,
      45,
      35,
      35,
      45,
      35,
      45,
      50,
      40
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 3,
        "renown": 6,
        "auto": false,
        "extra": [
          "交付 Paradise Fish x1"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 Paradise Fish x1"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 6,
        "auto": false,
        "extra": [
          "交付 Paradise Fish x1"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 Paradise Fish x1"
        ]
      }
    },
    "abilities": [
      {
        "name": "Spirits’ Voice",
        "level": "Auto"
      },
      {
        "name": "Spirits’ Guidance",
        "level": "Lv 20"
      },
      {
        "name": "Spirits’ Guidance+",
        "level": "Lv 35"
      }
    ],
    "gift": "Tales of Adventure"
  },
  {
    "id": "theodora",
    "en": "Theodora",
    "name": "忒奥多拉",
    "house": "theodora",
    "role": "物理",
    "growth": [
      70,
      50,
      30,
      40,
      40,
      40,
      30,
      30,
      50
    ],
    "requirements": {
      "cai": null,
      "dietrich": null,
      "theodora": {
        "chapter": 1,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      },
      "leda": null
    },
    "abilities": [
      {
        "name": "Royal Resolve",
        "level": "Auto"
      },
      {
        "name": "Unstoppable Force",
        "level": "详见来源"
      },
      {
        "name": "Direct Hit",
        "level": "详见来源"
      }
    ],
    "gift": "Pegasus Panorama"
  },
  {
    "id": "bonaventure",
    "en": "Bonaventure",
    "name": "Bonaventure",
    "house": "theodora",
    "role": "魔法",
    "growth": [
      35,
      35,
      45,
      40,
      50,
      30,
      40,
      35,
      40
    ],
    "requirements": {
      "cai": null,
      "dietrich": null,
      "theodora": {
        "chapter": 1,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      },
      "leda": null
    },
    "abilities": [
      {
        "name": "Sage Advice",
        "level": "Auto"
      },
      {
        "name": "Additional Intel",
        "level": "Lv 20"
      },
      {
        "name": "Additional Intel+",
        "level": "Lv 35"
      }
    ],
    "gift": "Dual Fish Knives"
  },
  {
    "id": "tobias",
    "en": "Tobias",
    "name": "Tobias",
    "house": "theodora",
    "role": "防守",
    "growth": [
      55,
      60,
      15,
      25,
      30,
      45,
      20,
      40,
      35
    ],
    "requirements": {
      "cai": null,
      "dietrich": null,
      "theodora": {
        "chapter": 1,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      },
      "leda": null
    },
    "abilities": [
      {
        "name": "Power Arts",
        "level": "Auto"
      },
      {
        "name": "All-Out Attack",
        "level": "Lv 20"
      },
      {
        "name": "All-Out Attack+",
        "level": "Lv 35"
      }
    ],
    "gift": null
  },
  {
    "id": "lilian",
    "en": "Lilian",
    "name": "Lilian",
    "house": "theodora",
    "role": "远程",
    "growth": [
      35,
      35,
      30,
      40,
      55,
      30,
      35,
      50,
      25
    ],
    "requirements": {
      "cai": {
        "chapter": 4,
        "support": 2,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 5,000G"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 2,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 5,000G"
        ]
      },
      "theodora": {
        "chapter": 4,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      },
      "leda": {
        "chapter": 4,
        "support": 2,
        "renown": 7,
        "auto": false,
        "extra": [
          "交付 5,000G"
        ]
      }
    },
    "abilities": [
      {
        "name": "Safety First",
        "level": "Auto"
      },
      {
        "name": "Upper Hand",
        "level": "Lv 20"
      },
      {
        "name": "Upper Hand+",
        "level": "Lv 35"
      }
    ],
    "gift": "Eastern Earrings"
  },
  {
    "id": "lysander",
    "en": "Lysander",
    "name": "Lysander",
    "house": "theodora",
    "role": "高速",
    "growth": [
      45,
      40,
      25,
      50,
      35,
      40,
      25,
      30,
      30
    ],
    "requirements": {
      "cai": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 Iron Spear x5"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 6,
        "auto": false,
        "extra": [
          "交付 Iron Spear x5"
        ]
      },
      "theodora": {
        "chapter": 4,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "交付 Iron Spear x5"
        ]
      }
    },
    "abilities": [
      {
        "name": "Racing Attack",
        "level": "Auto"
      },
      {
        "name": "Accelerate",
        "level": "Lv 20"
      },
      {
        "name": "Accelerate+",
        "level": "Lv 35"
      }
    ],
    "gift": "Flower Painting"
  },
  {
    "id": "ursula",
    "en": "Ursula",
    "name": "Ursula",
    "house": "other",
    "role": "高速",
    "growth": [
      40,
      35,
      35,
      50,
      50,
      35,
      30,
      40,
      45
    ],
    "requirements": {
      "cai": {
        "chapter": 4,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "完成 Talimun 外传",
          "同意三次"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "完成 Talimun 外传",
          "同意三次"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "完成 Talimun 外传",
          "同意三次"
        ]
      },
      "leda": null
    },
    "abilities": [
      {
        "name": "Management Skills",
        "level": "Auto"
      },
      {
        "name": "Seize the Chance",
        "level": "Lv 20"
      },
      {
        "name": "Seize the Chance+",
        "level": "Lv 35"
      }
    ],
    "gift": "Shield Portrait"
  },
  {
    "id": "ludia",
    "en": "Ludia",
    "name": "Ludia",
    "house": "other",
    "role": "高速",
    "growth": [
      40,
      35,
      20,
      55,
      45,
      30,
      20,
      30,
      30
    ],
    "requirements": {
      "cai": {
        "chapter": 4,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      }
    },
    "abilities": [
      {
        "name": "Falcon",
        "level": "Auto"
      },
      {
        "name": "Perception",
        "level": "Lv 20"
      },
      {
        "name": "Perception+",
        "level": "Lv 35"
      }
    ],
    "gift": "Eastern Black Silk"
  },
  {
    "id": "simon",
    "en": "Simon",
    "name": "Simon",
    "house": "other",
    "role": "物理",
    "growth": [
      50,
      50,
      20,
      35,
      40,
      40,
      25,
      50,
      35
    ],
    "requirements": {
      "cai": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 500G，硬币选择反面"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "交付 500G，硬币选择反面"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "交付 500G，硬币选择反面"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 6,
        "auto": false,
        "extra": [
          "交付 500G，硬币选择反面"
        ]
      }
    },
    "abilities": [
      {
        "name": "Close Call",
        "level": "Auto"
      },
      {
        "name": "Devil’s Luck",
        "level": "Lv 20"
      },
      {
        "name": "Devil’s Luck+",
        "level": "Lv 35"
      }
    ],
    "gift": "Rancid Garum"
  },
  {
    "id": "fianna",
    "en": "Fianna",
    "name": "Fianna",
    "house": "other",
    "role": "魔法",
    "growth": [
      30,
      35,
      55,
      30,
      40,
      20,
      45,
      25,
      40
    ],
    "requirements": {
      "cai": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 3,000G"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "交付 3,000G"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "交付 3,000G"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 5,
        "auto": false,
        "extra": [
          "交付 3,000G"
        ]
      }
    },
    "abilities": [
      {
        "name": "Graceful Light",
        "level": "Auto"
      },
      {
        "name": "Gift of Faith",
        "level": "Lv 20"
      },
      {
        "name": "Gift of Faith+",
        "level": "Lv 35"
      }
    ],
    "gift": "Flower Painting"
  },
  {
    "id": "leda",
    "en": "Leda",
    "name": "蕾达",
    "house": "leda",
    "role": "高速",
    "growth": [
      40,
      35,
      35,
      65,
      50,
      30,
      35,
      25,
      55
    ],
    "requirements": {
      "cai": null,
      "dietrich": null,
      "theodora": null,
      "leda": {
        "chapter": 1,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      }
    },
    "abilities": [
      {
        "name": "Blindside",
        "level": "Auto"
      },
      {
        "name": "Improviso",
        "level": "详见来源"
      }
    ],
    "gift": "Eastern Black Silk"
  },
  {
    "id": "buccar",
    "en": "Buccar",
    "name": "Buccar",
    "house": "leda",
    "role": "防守",
    "growth": [
      50,
      50,
      20,
      25,
      40,
      45,
      20,
      30,
      35
    ],
    "requirements": {
      "cai": null,
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "完成 Leda 外传"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "完成 Leda 外传"
        ]
      },
      "leda": {
        "chapter": 1,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      }
    },
    "abilities": [
      {
        "name": "Guardian’s Duty",
        "level": "Auto"
      },
      {
        "name": "Retaliatory Blow",
        "level": "Lv 20"
      },
      {
        "name": "Retaliatory Blow+",
        "level": "Lv 35"
      }
    ],
    "gift": "Rancid Garum"
  },
  {
    "id": "sirocco",
    "en": "Sirocco",
    "name": "Sirocco",
    "house": "leda",
    "role": "物理",
    "growth": [
      40,
      40,
      40,
      45,
      50,
      35,
      35,
      50,
      45
    ],
    "requirements": {
      "cai": {
        "chapter": 4,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 1,
        "renown": 5,
        "auto": false,
        "extra": [
          "完成个人委托"
        ]
      },
      "leda": {
        "chapter": 1,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      }
    },
    "abilities": [
      {
        "name": "Goddess’s Favor",
        "level": "Auto"
      },
      {
        "name": "Wind’s Caprice",
        "level": "Lv 20"
      },
      {
        "name": "Wind’s Caprice+",
        "level": "Lv 35"
      }
    ],
    "gift": "Portrait of Yu Phas"
  },
  {
    "id": "olympia",
    "en": "Olympia",
    "name": "Olympia",
    "house": "leda",
    "role": "魔法",
    "growth": [
      35,
      35,
      50,
      35,
      35,
      30,
      40,
      40,
      40
    ],
    "requirements": {
      "cai": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "完成三次个人委托"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 6,
        "auto": false,
        "extra": [
          "完成三次个人委托"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "完成三次个人委托"
        ]
      },
      "leda": {
        "chapter": 3,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      }
    },
    "abilities": [
      {
        "name": "Competitive Zeal",
        "level": "Auto"
      },
      {
        "name": "Ardent Nosferatu",
        "level": "Lv 20"
      },
      {
        "name": "Ardent Nosferatu+",
        "level": "Lv 35"
      }
    ],
    "gift": "Flower Painting"
  },
  {
    "id": "mu",
    "en": "Mu",
    "name": "Mu",
    "house": "leda",
    "role": "物理",
    "growth": [
      30,
      30,
      5,
      30,
      30,
      20,
      10,
      10,
      20
    ],
    "requirements": {
      "cai": {
        "chapter": 4,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "交付 Glirmosa x3"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "交付 Glirmosa x3"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "交付 Glirmosa x3"
        ]
      },
      "leda": {
        "chapter": 1,
        "support": 0,
        "renown": 0,
        "auto": true,
        "extra": []
      }
    },
    "abilities": [
      {
        "name": "Signs of Growth",
        "level": "Auto"
      },
      {
        "name": "Warrior’s Blood",
        "level": "Lv 20"
      },
      {
        "name": "Warrior’s Blood+",
        "level": "Lv 35"
      }
    ],
    "gift": "Candy Crystals"
  },
  {
    "id": "sha-lan",
    "en": "Sha Lan",
    "name": "Sha Lan",
    "house": "other",
    "role": "魔法",
    "growth": [
      35,
      30,
      45,
      35,
      50,
      30,
      45,
      35,
      40
    ],
    "requirements": {
      "cai": null,
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "完成 Anatolia 外传",
          "正确回答三道问题"
        ]
      },
      "theodora": null,
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "完成 Anatolia 外传",
          "正确回答三道问题"
        ]
      }
    },
    "abilities": [
      {
        "name": "Cooler Heads",
        "level": "Auto"
      },
      {
        "name": "Watchfulness",
        "level": "Lv 20"
      },
      {
        "name": "Watchfulness+",
        "level": "Lv 35"
      }
    ],
    "gift": "Special “Medicine”"
  },
  {
    "id": "nezha",
    "en": "Nezha",
    "name": "哪吒",
    "house": "other",
    "role": "物理",
    "growth": [
      45,
      45,
      25,
      45,
      50,
      35,
      25,
      30,
      25
    ],
    "requirements": {
      "cai": {
        "chapter": 4,
        "support": 3,
        "renown": 6,
        "auto": false,
        "extra": [
          "交付 Sandworm Meat x3"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "交付 Sandworm Meat x3"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 2,
        "renown": 6,
        "auto": false,
        "extra": [
          "交付 Sandworm Meat x3"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "交付 Sandworm Meat x3"
        ]
      }
    },
    "abilities": [
      {
        "name": "Quick Draw",
        "level": "Auto"
      },
      {
        "name": "Never Stop",
        "level": "Lv 20"
      },
      {
        "name": "Never Stop+",
        "level": "Lv 35"
      }
    ],
    "gift": "Portrait of Yu Phas"
  },
  {
    "id": "dadao",
    "en": "Dadao",
    "name": "Dadao",
    "house": "other",
    "role": "防守",
    "growth": [
      50,
      55,
      20,
      30,
      35,
      45,
      20,
      25,
      30
    ],
    "requirements": {
      "cai": {
        "chapter": 4,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "交付 Kothar Gar x2"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "交付 Kothar Gar x2"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 2,
        "renown": 5,
        "auto": false,
        "extra": [
          "交付 Kothar Gar x2"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 2,
        "renown": 5,
        "auto": false,
        "extra": [
          "交付 Kothar Gar x2"
        ]
      }
    },
    "abilities": [
      {
        "name": "One Chance",
        "level": "Auto"
      },
      {
        "name": "Full Strength",
        "level": "Lv 20"
      },
      {
        "name": "Full Strength+",
        "level": "Lv 35"
      }
    ],
    "gift": "Tales of Adventure"
  },
  {
    "id": "halvin",
    "en": "Halvin",
    "name": "Halvin",
    "house": "other",
    "role": "远程",
    "growth": [
      35,
      35,
      30,
      45,
      60,
      30,
      25,
      40,
      35
    ],
    "requirements": {
      "cai": {
        "chapter": 4,
        "support": 3,
        "renown": 5,
        "auto": false,
        "extra": [
          "交付 Dates x10"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "交付 Dates x10"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "交付 Dates x10"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "交付 Dates x10"
        ]
      }
    },
    "abilities": [
      {
        "name": "Adaptability",
        "level": "Auto"
      },
      {
        "name": "Halt Advance",
        "level": "Lv 20"
      },
      {
        "name": "Halt Advance+",
        "level": "Lv 35"
      }
    ],
    "gift": "Red Hair Clip"
  },
  {
    "id": "guzran",
    "en": "Guzran",
    "name": "Guzran",
    "house": "other",
    "role": "高速",
    "growth": [
      45,
      45,
      20,
      50,
      45,
      35,
      20,
      45,
      30
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 1,
        "renown": 2,
        "auto": false,
        "extra": [
          "教程招募"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": []
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": []
      },
      "leda": {
        "chapter": 4,
        "support": 1,
        "renown": 3,
        "auto": false,
        "extra": []
      }
    },
    "abilities": [
      {
        "name": "Hot-Headed",
        "level": "Auto"
      },
      {
        "name": "Top Form",
        "level": "Lv 20"
      },
      {
        "name": "Top Form+",
        "level": "Lv 35"
      }
    ],
    "gift": "Tales of Adventure"
  },
  {
    "id": "yang-jie",
    "en": "Yang Jie",
    "name": "杨杰",
    "house": "other",
    "role": "魔法",
    "growth": [
      50,
      30,
      40,
      35,
      35,
      30,
      40,
      40,
      25
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 2,
        "renown": 3,
        "auto": false,
        "extra": [
          "正确回答三道问题"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 1,
        "renown": 2,
        "auto": false,
        "extra": [
          "教程招募"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "正确回答三道问题"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "正确回答三道问题"
        ]
      }
    },
    "abilities": [
      {
        "name": "Monkly Havoc",
        "level": "Auto"
      },
      {
        "name": "Robust Health",
        "level": "Lv 20"
      },
      {
        "name": "Robust Health+",
        "level": "Lv 35"
      }
    ],
    "gift": null
  },
  {
    "id": "io",
    "en": "Io",
    "name": "Io",
    "house": "other",
    "role": "物理",
    "growth": [
      45,
      40,
      25,
      35,
      45,
      40,
      25,
      35,
      35
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "交付 4,000G"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 2,
        "renown": 3,
        "auto": false,
        "extra": [
          "交付 800G"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "交付 4,000G"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 1,
        "renown": 6,
        "auto": false,
        "extra": [
          "交付 1,500G"
        ]
      }
    },
    "abilities": [
      {
        "name": "With My Steed",
        "level": "Auto"
      },
      {
        "name": "Mounted Push",
        "level": "Lv 20"
      },
      {
        "name": "Mounted Push+",
        "level": "Lv 35"
      }
    ],
    "gift": "Portrait of Yu Phas"
  },
  {
    "id": "peppe",
    "en": "Peppe",
    "name": "Peppe",
    "house": "other",
    "role": "高速",
    "growth": [
      30,
      30,
      25,
      60,
      45,
      30,
      30,
      45,
      30
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 1,
        "renown": 9,
        "auto": false,
        "extra": [
          "完成 Bertrand 外传"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "完成 Bertrand 外传"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 2,
        "renown": 7,
        "auto": false,
        "extra": [
          "完成 Bertrand 外传"
        ]
      },
      "leda": null
    },
    "abilities": [
      {
        "name": "Hunter’s Snare",
        "level": "Auto"
      },
      {
        "name": "King’s Majesty",
        "level": "Lv 20"
      },
      {
        "name": "King’s Majesty+",
        "level": "Lv 35"
      }
    ],
    "gift": "Rancid Garum"
  },
  {
    "id": "noctula",
    "en": "Noctula",
    "name": "Noctula",
    "house": "other",
    "role": "物理",
    "growth": [
      50,
      45,
      20,
      45,
      40,
      40,
      20,
      35,
      30
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 1,
        "renown": 4,
        "auto": false,
        "extra": []
      },
      "dietrich": {
        "chapter": 4,
        "support": 1,
        "renown": 6,
        "auto": false,
        "extra": []
      },
      "theodora": {
        "chapter": 5,
        "support": 1,
        "renown": 3,
        "auto": false,
        "extra": []
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": []
      }
    },
    "abilities": [
      {
        "name": "Warrior’s Clarity",
        "level": "Auto"
      },
      {
        "name": "Attuned",
        "level": "Lv 20"
      },
      {
        "name": "Attuned+",
        "level": "Lv 35"
      }
    ],
    "gift": "Strategy Manuscript"
  },
  {
    "id": "sofia",
    "en": "Sofia",
    "name": "索菲娅",
    "house": "other",
    "role": "魔法",
    "growth": [
      35,
      30,
      45,
      30,
      40,
      25,
      40,
      30,
      40
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": []
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": []
      },
      "theodora": {
        "chapter": 5,
        "support": 1,
        "renown": 2,
        "auto": false,
        "extra": [
          "教程招募"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": []
      }
    },
    "abilities": [
      {
        "name": "Healing Knowledge",
        "level": "Auto"
      },
      {
        "name": "Distant Healing",
        "level": "Lv 20"
      },
      {
        "name": "Distant Healing+",
        "level": "Lv 35"
      }
    ],
    "gift": "Candy Crystals"
  },
  {
    "id": "catania",
    "en": "Catania",
    "name": "Catania",
    "house": "other",
    "role": "高速",
    "growth": [
      35,
      35,
      35,
      55,
      50,
      30,
      35,
      40,
      45
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": []
      },
      "dietrich": {
        "chapter": 4,
        "support": 1,
        "renown": 8,
        "auto": false,
        "extra": []
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": []
      },
      "leda": {
        "chapter": 4,
        "support": 1,
        "renown": 2,
        "auto": false,
        "extra": [
          "教程招募"
        ]
      }
    },
    "abilities": [
      {
        "name": "Punishing Squall",
        "level": "Auto"
      },
      {
        "name": "Wind My Friend",
        "level": "Lv 20"
      },
      {
        "name": "Wind My Friend+",
        "level": "Lv 35"
      }
    ],
    "gift": "Flower Painting"
  },
  {
    "id": "nydine",
    "en": "Nydine",
    "name": "Nydine",
    "house": "other",
    "role": "物理",
    "growth": [
      45,
      40,
      30,
      45,
      40,
      30,
      25,
      35,
      35
    ],
    "requirements": {
      "cai": {
        "chapter": 3,
        "support": 1,
        "renown": 6,
        "auto": false,
        "extra": [
          "交付 Bronze Axe x2"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 2,
        "renown": 5,
        "auto": false,
        "extra": [
          "交付 Bronze Axe x2"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 5,
        "auto": false,
        "extra": [
          "交付 Iron Axe x3"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "交付 Iron Axe x3"
        ]
      }
    },
    "abilities": [
      {
        "name": "Barge Through",
        "level": "Auto"
      },
      {
        "name": "At a Gallop",
        "level": "Lv 20"
      },
      {
        "name": "At a Gallop+",
        "level": "Lv 35"
      }
    ],
    "gift": "Pegasus Panorama"
  },
  {
    "id": "zarcone",
    "en": "Zarcone",
    "name": "Zarcone",
    "house": "other",
    "role": "远程",
    "growth": [
      40,
      30,
      20,
      35,
      60,
      30,
      25,
      30,
      15
    ],
    "requirements": {
      "cai": {
        "chapter": 5,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 10,000G to 10G"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": [
          "交付 10,000G to 10G"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 1,
        "renown": 4,
        "auto": false,
        "extra": [
          "交付 10,000G to 10G"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 2,
        "renown": 5,
        "auto": false,
        "extra": [
          "交付 10,000G to 10G"
        ]
      }
    },
    "abilities": [
      {
        "name": "Hatchet Man",
        "level": "Auto"
      },
      {
        "name": "Vulgar Conduct",
        "level": "Lv 20"
      },
      {
        "name": "Vulgar Conduct+",
        "level": "Lv 35"
      }
    ],
    "gift": null
  },
  {
    "id": "majide",
    "en": "Majide",
    "name": "Majide",
    "house": "other",
    "role": "物理",
    "growth": [
      65,
      50,
      15,
      20,
      30,
      40,
      10,
      25,
      5
    ],
    "requirements": {
      "cai": {
        "chapter": 5,
        "support": 2,
        "renown": 5,
        "auto": false,
        "extra": [
          "同意三次"
        ]
      },
      "dietrich": {
        "chapter": 4,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "同意三次"
        ]
      },
      "theodora": {
        "chapter": 5,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "同意三次"
        ]
      },
      "leda": {
        "chapter": 4,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "同意三次"
        ]
      }
    },
    "abilities": [
      {
        "name": "Hellbent Axe",
        "level": "Auto"
      },
      {
        "name": "Fear Nothing",
        "level": "Lv 20"
      },
      {
        "name": "Fear Nothing+",
        "level": "Lv 35"
      }
    ],
    "gift": null
  },
  {
    "id": "benditz",
    "en": "Benditz",
    "name": "Benditz",
    "house": "other",
    "role": "物理",
    "growth": [
      50,
      35,
      20,
      35,
      50,
      35,
      25,
      30,
      35
    ],
    "requirements": {
      "cai": {
        "chapter": 6,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": []
      },
      "dietrich": {
        "chapter": 5,
        "support": 2,
        "renown": 7,
        "auto": false,
        "extra": []
      },
      "theodora": {
        "chapter": 6,
        "support": 1,
        "renown": 8,
        "auto": false,
        "extra": []
      },
      "leda": {
        "chapter": 5,
        "support": 3,
        "renown": 7,
        "auto": false,
        "extra": []
      }
    },
    "abilities": [
      {
        "name": "Wheeled Warrior",
        "level": "Auto"
      },
      {
        "name": "Chariot Stagger",
        "level": "Lv 20"
      },
      {
        "name": "Chariot Stagger+",
        "level": "Lv 35"
      }
    ],
    "gift": "Rancid Garum"
  },
  {
    "id": "inyoni",
    "en": "Inyoni",
    "name": "Inyoni",
    "house": "other",
    "role": "物理",
    "growth": [
      40,
      50,
      20,
      35,
      40,
      40,
      30,
      40,
      30
    ],
    "requirements": {
      "cai": {
        "chapter": 8,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 6,000G"
        ]
      },
      "dietrich": {
        "chapter": 8,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 6,000G"
        ]
      },
      "theodora": {
        "chapter": 9,
        "support": 1,
        "renown": 9,
        "auto": false,
        "extra": [
          "交付 4,000G"
        ]
      },
      "leda": {
        "chapter": 9,
        "support": 1,
        "renown": 7,
        "auto": false,
        "extra": [
          "交付 3,000G"
        ]
      }
    },
    "abilities": [
      {
        "name": "Heavy-Bow User",
        "level": "Auto"
      },
      {
        "name": "Pierce",
        "level": "Lv 20"
      },
      {
        "name": "Pierce+",
        "level": "Lv 35"
      }
    ],
    "gift": "Strategy Manuscript"
  },
  {
    "id": "jasmine",
    "en": "Jasmine",
    "name": "茉莉",
    "house": "other",
    "role": "防守",
    "growth": [
      50,
      40,
      20,
      30,
      45,
      45,
      25,
      40,
      45
    ],
    "requirements": {
      "cai": {
        "chapter": 6,
        "support": 1,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 2,000G"
        ]
      },
      "dietrich": {
        "chapter": 6,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "交付 5,000G"
        ]
      },
      "theodora": {
        "chapter": 7,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 5,000G"
        ]
      },
      "leda": {
        "chapter": 6,
        "support": 2,
        "renown": 4,
        "auto": false,
        "extra": [
          "交付 500G"
        ]
      }
    },
    "abilities": [
      {
        "name": "Expert Counter",
        "level": "Auto"
      },
      {
        "name": "Raging Counter",
        "level": "Lv 20"
      },
      {
        "name": "Raging Counter+",
        "level": "Lv 35"
      }
    ],
    "gift": "Strategy Manuscript"
  },
  {
    "id": "alexandra",
    "en": "Alexandra",
    "name": "Alexandra",
    "house": "other",
    "role": "高速",
    "growth": [
      30,
      35,
      35,
      55,
      45,
      30,
      40,
      50,
      50
    ],
    "requirements": {
      "cai": {
        "chapter": 7,
        "support": 2,
        "renown": 7,
        "auto": false,
        "extra": []
      },
      "dietrich": {
        "chapter": 7,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": []
      },
      "theodora": {
        "chapter": 8,
        "support": 1,
        "renown": 6,
        "auto": false,
        "extra": []
      },
      "leda": {
        "chapter": 7,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": []
      }
    },
    "abilities": [
      {
        "name": "Silver Maiden",
        "level": "Auto"
      },
      {
        "name": "Soar",
        "level": "Lv 20"
      },
      {
        "name": "Soar+",
        "level": "Lv 35"
      }
    ],
    "gift": "Pegasus Panorama"
  },
  {
    "id": "nuzzuo",
    "en": "Nuzzuo",
    "name": "Nuzzuo",
    "house": "other",
    "role": "高速",
    "growth": [
      50,
      50,
      15,
      55,
      45,
      20,
      15,
      25,
      35
    ],
    "requirements": {
      "cai": {
        "chapter": 7,
        "support": 2,
        "renown": 6,
        "auto": false,
        "extra": [
          "交付 Iron Bow x3"
        ]
      },
      "dietrich": {
        "chapter": 8,
        "support": 1,
        "renown": 9,
        "auto": false,
        "extra": [
          "交付 Iron Bow x2"
        ]
      },
      "theodora": {
        "chapter": 9,
        "support": 1,
        "renown": 6,
        "auto": false,
        "extra": [
          "交付 Iron Bow x3"
        ]
      },
      "leda": {
        "chapter": 8,
        "support": 3,
        "renown": 9,
        "auto": false,
        "extra": [
          "交付 Iron Bow x3"
        ]
      }
    },
    "abilities": [
      {
        "name": "Har Hali Wisdom",
        "level": "Auto"
      },
      {
        "name": "Precision Strike",
        "level": "Lv 20"
      },
      {
        "name": "Precision Strike+",
        "level": "Lv 35"
      }
    ],
    "gift": "Arrowhead Gem"
  },
  {
    "id": "kiroc",
    "en": "Kiroc",
    "name": "Kiroc",
    "house": "other",
    "role": "高速",
    "growth": [
      55,
      40,
      15,
      55,
      50,
      30,
      15,
      30,
      25
    ],
    "requirements": {
      "cai": {
        "chapter": 6,
        "support": 3,
        "renown": 8,
        "auto": false,
        "extra": [
          "交付 Pure Water x8"
        ]
      },
      "dietrich": {
        "chapter": 6,
        "support": 1,
        "renown": 4,
        "auto": false,
        "extra": [
          "交付 Pure Water x3"
        ]
      },
      "theodora": {
        "chapter": 6,
        "support": 3,
        "renown": 10,
        "auto": false,
        "extra": [
          "交付 Pure Water x8"
        ]
      },
      "leda": {
        "chapter": 5,
        "support": 1,
        "renown": 4,
        "auto": false,
        "extra": [
          "交付 Pure Water x3"
        ]
      }
    },
    "abilities": [
      {
        "name": "Tyranny",
        "level": "Auto"
      },
      {
        "name": "Menace",
        "level": "Lv 20"
      },
      {
        "name": "Menace+",
        "level": "Lv 35"
      }
    ],
    "gift": null
  }
];
const WEAVE_CLASSES=[
  {
    "en": "Noble",
    "growth": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ]
  },
  {
    "en": "Commoner",
    "growth": [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ]
  },
  {
    "en": "Gladiator",
    "growth": [
      10,
      10,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ]
  },
  {
    "en": "Hunter",
    "growth": [
      10,
      0,
      0,
      10,
      10,
      0,
      0,
      0,
      0
    ]
  },
  {
    "en": "Soldier",
    "growth": [
      10,
      5,
      0,
      -5,
      5,
      10,
      0,
      0,
      0
    ]
  },
  {
    "en": "Ornius Rider",
    "growth": [
      10,
      0,
      0,
      10,
      0,
      0,
      5,
      5,
      0
    ]
  },
  {
    "en": "Diviner",
    "growth": [
      5,
      -5,
      15,
      0,
      5,
      -5,
      10,
      0,
      0
    ]
  },
  {
    "en": "Myrmidon",
    "growth": [
      10,
      0,
      0,
      15,
      10,
      0,
      0,
      5,
      5
    ]
  },
  {
    "en": "Brigand",
    "growth": [
      15,
      15,
      -5,
      5,
      0,
      5,
      0,
      0,
      5
    ]
  },
  {
    "en": "Pugilist",
    "growth": [
      15,
      10,
      -5,
      10,
      5,
      10,
      0,
      0,
      5
    ]
  },
  {
    "en": "Archer",
    "growth": [
      10,
      0,
      0,
      10,
      15,
      5,
      0,
      5,
      5
    ]
  },
  {
    "en": "Rogue",
    "growth": [
      10,
      0,
      0,
      15,
      10,
      0,
      5,
      5,
      0
    ]
  },
  {
    "en": "Armored Knight",
    "growth": [
      10,
      10,
      -5,
      -5,
      5,
      25,
      -5,
      0,
      5
    ]
  },
  {
    "en": "Light Cavalry",
    "growth": [
      10,
      5,
      -5,
      5,
      0,
      5,
      0,
      5,
      10
    ]
  },
  {
    "en": "Charioteer",
    "growth": [
      10,
      5,
      -5,
      -5,
      15,
      10,
      0,
      5,
      10
    ]
  },
  {
    "en": "Armored Ornius Rider",
    "growth": [
      10,
      0,
      -5,
      10,
      5,
      10,
      0,
      5,
      5
    ]
  },
  {
    "en": "Wing Soldier",
    "growth": [
      10,
      0,
      5,
      0,
      5,
      5,
      5,
      5,
      10
    ]
  },
  {
    "en": "Shaman",
    "growth": [
      5,
      -5,
      15,
      10,
      10,
      -10,
      10,
      10,
      0
    ]
  },
  {
    "en": "Priest",
    "growth": [
      5,
      -5,
      10,
      5,
      5,
      -10,
      15,
      15,
      10
    ]
  },
  {
    "en": "Shido",
    "growth": [
      10,
      5,
      0,
      15,
      10,
      0,
      -5,
      5,
      5
    ]
  },
  {
    "en": "Warrior",
    "growth": [
      20,
      20,
      -5,
      0,
      0,
      5,
      -5,
      0,
      5
    ]
  },
  {
    "en": "Blacksmith",
    "growth": [
      15,
      10,
      10,
      0,
      5,
      10,
      10,
      0,
      5
    ]
  },
  {
    "en": "Sniper",
    "growth": [
      10,
      5,
      0,
      10,
      20,
      5,
      5,
      5,
      5
    ]
  },
  {
    "en": "Forest Knight",
    "growth": [
      10,
      5,
      0,
      10,
      10,
      5,
      5,
      5,
      5
    ]
  },
  {
    "en": "Ranger",
    "growth": [
      10,
      5,
      0,
      15,
      15,
      0,
      10,
      15,
      0
    ]
  },
  {
    "en": "Guardian",
    "growth": [
      10,
      10,
      0,
      0,
      5,
      10,
      15,
      5,
      5
    ]
  },
  {
    "en": "Dreadnought",
    "growth": [
      15,
      15,
      -5,
      -10,
      5,
      30,
      -10,
      0,
      5
    ]
  },
  {
    "en": "Bardinger",
    "growth": [
      10,
      10,
      -5,
      0,
      0,
      5,
      10,
      5,
      10
    ]
  },
  {
    "en": "Elephant Rider",
    "growth": [
      20,
      10,
      -5,
      -10,
      20,
      15,
      -5,
      5,
      10
    ]
  },
  {
    "en": "Caladrius",
    "growth": [
      15,
      0,
      10,
      10,
      5,
      10,
      10,
      5,
      5
    ]
  },
  {
    "en": "Dragoon",
    "growth": [
      15,
      5,
      0,
      5,
      0,
      10,
      10,
      10,
      5
    ]
  },
  {
    "en": "Ovate",
    "growth": [
      10,
      -5,
      20,
      5,
      15,
      -10,
      15,
      10,
      0
    ]
  },
  {
    "en": "Bishop",
    "growth": [
      10,
      -5,
      15,
      0,
      5,
      -10,
      20,
      20,
      10
    ]
  },
  {
    "en": "Troubadour",
    "growth": [
      10,
      0,
      15,
      0,
      5,
      5,
      15,
      15,
      10
    ]
  },
  {
    "en": "Swordmaster",
    "growth": [
      15,
      10,
      0,
      20,
      15,
      0,
      0,
      5,
      5
    ]
  },
  {
    "en": "High Savant",
    "growth": [
      10,
      15,
      15,
      10,
      5,
      5,
      5,
      5,
      5
    ]
  },
  {
    "en": "Battlemaster",
    "growth": [
      25,
      25,
      -5,
      5,
      -5,
      10,
      -5,
      -5,
      5
    ]
  },
  {
    "en": "War Monk",
    "growth": [
      15,
      10,
      0,
      15,
      0,
      5,
      15,
      5,
      5
    ]
  },
  {
    "en": "Bow Adept",
    "growth": [
      15,
      5,
      0,
      15,
      20,
      5,
      5,
      5,
      5
    ]
  },
  {
    "en": "Bow Knight",
    "growth": [
      10,
      10,
      0,
      15,
      10,
      5,
      0,
      5,
      5
    ]
  },
  {
    "en": "Shadow Seeker",
    "growth": [
      15,
      5,
      0,
      25,
      15,
      0,
      10,
      15,
      0
    ]
  },
  {
    "en": "Sentinel",
    "growth": [
      15,
      15,
      0,
      5,
      5,
      10,
      15,
      5,
      5
    ]
  },
  {
    "en": "Castle Knight",
    "growth": [
      25,
      20,
      -5,
      -15,
      5,
      30,
      -10,
      0,
      5
    ]
  },
  {
    "en": "Orichaldia",
    "growth": [
      15,
      15,
      -5,
      5,
      0,
      5,
      5,
      5,
      10
    ]
  },
  {
    "en": "Great Knight",
    "growth": [
      20,
      20,
      -5,
      -10,
      0,
      15,
      -10,
      0,
      5
    ]
  },
  {
    "en": "Celestial Trooper",
    "growth": [
      15,
      5,
      -5,
      10,
      5,
      5,
      15,
      15,
      10
    ]
  },
  {
    "en": "Bau Lord",
    "growth": [
      15,
      5,
      0,
      5,
      0,
      10,
      10,
      10,
      5
    ]
  },
  {
    "en": "Druid",
    "growth": [
      10,
      -5,
      30,
      10,
      15,
      -10,
      20,
      10,
      0
    ]
  },
  {
    "en": "Wiseman",
    "growth": [
      10,
      -5,
      20,
      5,
      0,
      -10,
      25,
      20,
      10
    ]
  },
  {
    "en": "Valkyrium",
    "growth": [
      10,
      0,
      15,
      5,
      5,
      5,
      10,
      15,
      10
    ]
  },
  {
    "en": "The Blade",
    "growth": [
      15,
      10,
      10,
      20,
      20,
      5,
      5,
      5,
      10
    ]
  },
  {
    "en": "The Apsara",
    "growth": [
      15,
      5,
      10,
      25,
      15,
      5,
      5,
      10,
      30
    ]
  },
  {
    "en": "The Eternal",
    "growth": [
      30,
      30,
      0,
      10,
      0,
      15,
      0,
      0,
      10
    ]
  },
  {
    "en": "The Godhand",
    "growth": [
      15,
      10,
      10,
      15,
      5,
      10,
      15,
      5,
      10
    ]
  },
  {
    "en": "The Calamity",
    "growth": [
      15,
      5,
      15,
      25,
      20,
      5,
      15,
      15,
      5
    ]
  },
  {
    "en": "The Trident",
    "growth": [
      15,
      15,
      5,
      10,
      10,
      15,
      15,
      5,
      10
    ]
  },
  {
    "en": "The Cavalier",
    "growth": [
      20,
      15,
      5,
      10,
      10,
      15,
      10,
      5,
      15
    ]
  },
  {
    "en": "The Avatar",
    "growth": [
      10,
      -5,
      30,
      10,
      5,
      -5,
      30,
      20,
      10
    ]
  }
];
