let theme='dark';
try { theme=localStorage.getItem('fodlan-theme-v1')==='light'?'light':'dark'; } catch {}
document.documentElement.dataset.theme=theme;
function updateThemeButton(){const button=document.querySelector('#theme-toggle');if(!button)return;button.textContent=theme==='dark'?'日间模式':'夜间模式';button.setAttribute('aria-label',theme==='dark'?'切换至日间模式':'切换至夜间模式');}
function toggleTheme(){theme=theme==='dark'?'light':'dark';document.documentElement.dataset.theme=theme;try{localStorage.setItem('fodlan-theme-v1',theme);}catch{}updateThemeButton();}
let themeBound=false;
document.addEventListener('DOMContentLoaded',()=>{updateThemeButton();if(themeBound)return;themeBound=true;document.addEventListener('click',e=>{if(e.target.closest('#theme-toggle'))toggleTheme();});});
