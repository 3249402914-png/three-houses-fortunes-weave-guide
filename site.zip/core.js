'use strict';
const SKILL_RANKS=['E','E+','D','D+','C','C+','B','B+','A','A+','S','S+'];
function recruitmentRequirement(c,support='无') {
 const maps={'无':{'D':'D','C':'C','B':'B','B+':'B+'},'C':{'D':'D','C':'C','B':'C+','B+':'B'},'C+':{'D':'D','C':'D+','B':'C','B+':'C+'},'B':{'D':'E+','C':'D','B':'D+','B+':'D+'},'B+':{'D':'E+','C':'E+','B':'D','B+':'D+'},'A':{'D':'E','C':'E','B':'E','B+':'E'}};
 const ratio={'无':1,'C':.8,'C+':.6,'B':.4,'B+':.2,'A':0}[support]??1;
 return {value:c.value*ratio,rank:c.rank?(maps[support]||maps['无'])[c.rank]:''};
}
function availability(c,p){
 const route=ROUTES[p.route],ch=Number(p.chapter),home=route.house;
 if(c.id==='byleth')return {ok:true,label:'主角',text:'开局加入。'};
 if(c.house==='wolves')return {ok:p.dlc&&ch<=12,label:p.dlc?(ch<=12?'DLC 直接邀请':'窗口已过'):'需要 DLC',text:c.note};
 if(c.id==='anna')return {ok:p.dlc&&ch>=3&&ch<=12,label:!p.dlc?'需要 DLC':ch<3?'第 3 章开放':ch>12?'窗口已过':'可邀请',text:c.note};
 if(c.id==='jeritza')return {ok:p.route==='cf'&&ch>=13,label:p.route==='cf'?(ch>=13?'剧情加入':'第 13 章加入'):'路线不可用',text:c.note};
 if(['edelgard','hubert'].includes(c.id))return {ok:home==='eagles'&&(p.route==='cf'||ch<=11),label:home==='eagles'?(p.route==='ss'&&ch>=12?'已离队':'原班成员'):'不可挖角',text:c.note};
 if(['dimitri','dedue','claude'].includes(c.id)){const ok=c.house===home;return {ok,label:ok?'原班成员':'不可挖角',text:c.note};}
 if(c.id==='hilda'&&home==='eagles')return {ok:p.route==='ss'&&ch===12,label:p.route==='cf'?'路线不可用':ch===12?'本章可邀请':ch<12?'第 12 章开放':'窗口已过',text:c.note};
 if(c.house===home)return {ok:true,label:'原班成员',text:'选择该学级时自动加入。'};
 if(c.house!=='church')return {ok:ch<=12,label:ch>12?'学院篇窗口已过':c.id==='sylvain'&&p.gender==='female'?'直接邀请':'可尝试挖角',text:c.note||'主角满足属性与技能条件后，在散步中邀请。'};
 if(['seteth','flayn','catherine','cyril'].includes(c.id)&&p.route==='cf'&&(c.id!=='flayn'||ch>=12))return {ok:false,label:'路线不可用',text:c.note};
 if(c.id==='gilbert')return {ok:p.route==='am'&&ch>=13,label:p.route!=='am'?'路线不可用':ch<13?'第 13 章加入':'剧情加入',text:c.note};
 const start={seteth:12,flayn:7,hanneman:8,manuela:8,alois:11,catherine:home==='eagles'?12:4,shamir:6,cyril:home==='eagles'?12:5}[c.id];
 return {ok:ch>=start,label:ch<start?`第 ${start} 章开放`:ch>12?'已招募者可用':'可加入',text:c.note};
}
function recruitmentCheck(c,p,support,stat,rank){
 const a=availability(c,p);const r=recruitmentRequirement(c,support);
 if(!a.ok)return {pass:false,text:a.label,req:r};
 if(a.label==='原班成员'||c.id==='byleth')return {pass:true,text:'本学级自动加入，无需挖角。',req:r};
 if(c.id==='sylvain'&&p.gender==='female')return {pass:true,text:'女性主角可在学院篇直接邀请希尔凡。',req:r};
 if(c.house==='wolves'||c.id==='anna')return {pass:true,text:'满足 DLC 解锁条件后，在学院篇对话邀请。',req:r};
 if(!c.stat)return {pass:true,text:'按角色详情中的剧情加入条件确认。',req:r};
 if(Number(p.chapter)>12)return {pass:false,text:'普通学生的学院篇邀请窗口已结束；未挖角者不能靠属性补招。',req:r};
 const pass=Number(stat)>=r.value&&(!c.rank||SKILL_RANKS.indexOf(rank)>=SKILL_RANKS.indexOf(r.rank));
 return {pass,text:pass?'已达到直接邀请门槛；在散步中选择挖角。':'尚未达到直接邀请门槛，继续训练主角或提高支援。',req:r};
}
if(typeof module!=='undefined')module.exports={SKILL_RANKS,recruitmentRequirement,availability,recruitmentCheck};
